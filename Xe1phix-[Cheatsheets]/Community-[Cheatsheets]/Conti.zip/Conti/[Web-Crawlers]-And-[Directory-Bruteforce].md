# 08 - Web Crawlers and Directory Bruteforce

TODO: Fill this information

## 8.1 - Sublist3r2

## 8.1.1 - Help Menu

`$ sublist3r2 -h`

## 8.2 - Gobuster

### 8.2.1 - Help Menu

`$ gobuster dir -h`

### 8.2.2 - Usage

`$ gobuster dir -u <URL> --random-agent -t 32 -w wordlist.txt -e php,txt,sh -x 404 -o output.txt`

## 8.3 - Ffuf

### 8.3.1 - Usage

`$ ffuf -u http[s]://<IP>/FUZZ -w wordlist.txt -t 5`

## 8.4 - Wfuzz

### 8.4.1 - Usage

`$ wfuzz --hc 404`

## 8.5 - Dirb

## 8.6 - Metasploit

- **Metasploit auxilary module HTTP Directory Scanner**

```
msf > use auxiliary/scanner/http/dir_scanner

msf auxiliary(scanner/http/dir_scanner) > options

Module options (auxiliary/scanner/http/dir_scanner):

   Name        Current Setting                          Required  Description
   ----        ---------------                          --------  -----------
   DICTIONARY  /opt/metasploit/data/wmap/wmap_dirs.txt  no        Path of word dictionary to use
   PATH        /                                        yes       The path  to identify files
   Proxies                                              no        A proxy chain of format type:host:port[,type:host:port][...]
   RHOSTS                                               yes       The target host(s), see https://docs.metasploit.com/docs/using-metasploit/basics/using-metasploit.html
   RPORT       80                                       yes       The target port (TCP)
   SSL         false                                    no        Negotiate SSL/TLS for outgoing connections
   THREADS     1                                        yes       The number of concurrent threads (max one per host)
   VHOST                                                no        HTTP server virtual host


View the full module info with the info, or info -d command.

msf auxiliary(scanner/http/dir_scanner) > set path <uri_path>

msf auxiliary(scanner/http/dir_scanner) > set dictionary </path/to/directories-wordlist.txt>

msf auxiliary(scanner/http/dir_scanner) > set threads 8

msf auxiliary(scanner/http/dir_scanner) > set rhosts <IP>

msf auxiliary(scanner/http/dir_scanner) > set rport <PORT>

msf auxiliary(scanner/http/dir_scanner) > run
```

- **Metasploit auxilary module HTTP Directory Listing Scanner**

```
msf > use auxiliary/scanner/http/dir_listing

msf auxiliary(scanner/http/dir_listing) > options

Module options (auxiliary/scanner/http/dir_listing):

   Name     Current Setting  Required  Description
   ----     ---------------  --------  -----------
   PATH     /                yes       The path to identify directory listing
   Proxies                   no        A proxy chain of format type:host:port[,type:host:port][...]
   RHOSTS                    yes       The target host(s), see https://docs.metasploit.com/docs/using-metasploit/basics/using-metasploit.html
   RPORT    80               yes       The target port (TCP)
   SSL      false            no        Negotiate SSL/TLS for outgoing connections
   THREADS  1                yes       The number of concurrent threads (max one per host)
   VHOST                     no        HTTP server virtual host

msf auxiliary(scanner/http/dir_listing) > set path </uri_path>

msf auxiliary(scanner/http/dir_listing) > set threads 8

msf auxiliary(scanner/http/dir_listing) > set rhosts <IP>

msf auxiliary(scanner/http/dir_listing) > set rport <PORT>

msf auxiliary(scanner/http/dir_listing) > run
```

- **Metasploit auxilary module HTTP Interesting File Scanner**

```
msf > use auxiliary/scanner/http/files_dir

msf auxiliary(scanner/http/files_dir) > options

Module options (auxiliary/scanner/http/files_dir):

   Name        Current Setting                           Required  Description
   ----        ---------------                           --------  -----------
   DICTIONARY  /opt/metasploit/data/wmap/wmap_files.txt  no        Path of word dictionary to use
   EXT                                                   no        Append file extension to use
   PATH        /                                         yes       The path  to identify files
   Proxies                                               no        A proxy chain of format type:host:port[,type:host:port][...]
   RHOSTS                                                yes       The target host(s), see https://docs.metasploit.com/docs/using-metasploit/basics/using-metasploit.html
   RPORT       80                                        yes       The target port (TCP)
   SSL         false                                     no        Negotiate SSL/TLS for outgoing connections
   THREADS     1                                         yes       The number of concurrent threads (max one per host)
   VHOST                                                 no        HTTP server virtual host


View the full module info with the info, or info -d command.

msf auxiliary(scanner/http/files_dir) > set path </uri_path>

msf auxiliary(scanner/http/files_dir) > set ext <.php | .html | .htm | .tar.gz | .zip | .db | .txt | .js>

msf auxiliary(scanner/http/files_dir) > set dictionary </path/to/directories-wordlist.txt>

msf auxiliary(scanner/http/files_dir) > set threads 8

msf auxiliary(scanner/http/files_dir) > set rhosts <IP>

msf auxiliary(scanner/http/files_dir) > set rport <PORT>

msf auxiliary(scanner/http/files_dir) > run
```

## References

- [Tutorial for Gobuster Tool](https://sitechsecurity.wordpress.com/2020/07/14/tutorial-for-gobuster-tool/)

- [Wfuzz the power of evil](https://blog.certcube.com/wfuzz-the-power-of-evil/)