# DNSRecon

## Usage

`$ dnsrecon -d zonetransfers.me -a -n <DNS_IP>`

`$ dnsrecon -d zonetransfers.me -t axfr`

`$ dnsrecon -r <IP_DNS>/<CIDR> -n <IP_DNS>`