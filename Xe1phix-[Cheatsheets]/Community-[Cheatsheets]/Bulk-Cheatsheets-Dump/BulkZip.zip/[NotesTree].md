.
├── Active-Directory-Fun
├── Awesome-Advanced-Windows-Exploitation-References
├── Awesome-Hacking-Resources
├── AwesomeXSS
│   └── Database
├── Books
├── Bypassing-Web-Application-Firewalls
├── ctf
│   └── natas
├── escalationserver
├── Hydra-Cheatsheet
├── IntruderPayloads
│   ├── BurpAttacks
│   ├── FuzzLists
│   ├── Plugins
│   └── Uploads
├── Linux-Privilege-Escalation
├── metasploit scripts
├── MSF-Venom-Cheatsheet
├── Notes VA
│   └── lpeworkshop
├── Offensive-Security-OSCP-Cheatsheets
│   ├── ctfs-walkthroughs
│   ├── lab
│   ├── memory-forensics
│   ├── offensive-security
│   └── offensive-security-experiments
├── oscp
│   ├── recon_enum
│   ├── reports
│   └── templates
├── OSCP-Materials-master
│   ├── Cheat Sheets
│   ├── Linux Privilege Escalation and Post Exploitation
│   ├── Metasploit-Meterpreter-Msfvenom
│   ├── PASSWORD CRACKING and Usefull TOOLS and Commands
│   ├── SHELLCODE and Buffer Over Flow
│   ├── Understand Privilege Escalation
│   └── Window Privilege Escalation and Post Exploitation
├── OSCPRepo
│   ├── CheetSheets
│   ├── KeepNotes
│   ├── lists
│   ├── Local Info Enum
│   ├── PDFs&Documents
│   ├── Priv Esc Checks
│   ├── Process&Methodology
│   ├── Reporting
│   ├── Scanning&Recon
│   ├── scripts
│   └── Tools
├── PayloadsAllTheThings
│   ├── AWS Amazon Bucket S3
│   ├── Command Injection
│   ├── CRLF Injection
│   ├── CSRF Injection
│   ├── CSV Injection
│   ├── CVE Exploits
│   ├── Directory Traversal
│   ├── File Inclusion
│   ├── GraphQL Injection
│   ├── Insecure Deserialization
│   ├── Insecure Direct Object References
│   ├── Insecure Management Interface
│   ├── Insecure Source Code Management
│   ├── JSON Web Token
│   ├── LaTeX Injection
│   ├── LDAP Injection
│   ├── Methodology and Resources
│   ├── NoSQL Injection
│   ├── OAuth
│   ├── Open Redirect
│   ├── SAML Injection
│   ├── Server Side Request Forgery
│   ├── Server Side Template Injection
│   ├── SQL Injection
│   ├── _template_vuln
│   ├── Type Juggling
│   ├── Upload Insecure Files
│   ├── Web Cache Deception
│   ├── Web Sockets
│   ├── XPATH Injection
│   ├── XSS Injection
│   └── XXE Injection
├── penbook
│   ├── assets
│   ├── physical_access_to_machine
│   ├── styles
│   └── writeups
├── pentestbook
│   ├── assets
│   ├── physical_access_to_machine
│   ├── styles
│   └── writeups
├── pentest_compilation
├── Powershell-Cheatsheet
├── pronotes
├── python-pty-shells-master
├── Red-Team-Infrastructure-Wiki
│   └── images
├── resource-threat-hunting
├── SCADA PLC ICS Pentest PDFs
│   └── awesome-industrial-control-system-security
├── SecLists
│   ├── Discovery
│   ├── Fuzzing
│   ├── IOCs
│   ├── Miscellaneous
│   ├── Passwords
│   ├── Pattern-Matching
│   ├── Payloads
│   ├── Usernames
│   └── Web-Shells
├── security-cheatsheets
├── Web-CTF-Cheatsheet
│   └── scripts
├── Windows-Privilege-Escalation
└── xapax.github.io
    ├── css
    ├── img
    ├── js
    └── reveng

122 directories
