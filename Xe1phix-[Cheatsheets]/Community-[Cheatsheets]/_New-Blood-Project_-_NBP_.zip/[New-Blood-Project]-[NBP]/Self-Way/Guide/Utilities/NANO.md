# NANO

| Shortcut | Description |
|----------|-------------|
nano filename |	Open file for editing in Nano
Arrow keys | Move cursor up, down, left and right
Ctrl+A, Ctrl+E | Move cursor to start and end of the line
Ctrl+Y/Ctrl+V | Move page up and down
Ctrl+_ | Move cursor to a certain location
Alt+A and then use arrow key | Set a marker and select text
Alt+6 | Copy the selected text
Ctrl+K | Cut the selected text
Ctrl+U | Paste the selected text
Ctrl+6 | Cancel the selection
Ctrl+K | Cut/delete entire line
Alt+U | Undo last action
Alt+E | Redo last action
Ctrl+W, Alt+W | Search for text, move to next match
Ctrl+\ | Search and replace
Ctrl+O | Save the modification
Ctrl+X | Exit the editor
