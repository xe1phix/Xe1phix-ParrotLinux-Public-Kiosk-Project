# SHODAN QUERY

## TAG : DEFAULT

default usernames and passwords

    https://www.shodan.io/search?query=default+usernames+and+passwords

Webs Httpd - Default Password

    https://www.shodan.io/search?query=default+password+product:"GoAhead-Webs+httpd"

Open BlueIris

    https://www.shodan.io/search?query=http.favicon.hash%3A-520888198+-401+-title%3Alogin

password is

    https://www.shodan.io/search?query="password+is"+OR+"default+is"+-"required"

Plesk - Default Title

    https://www.shodan.io/search?query=X-Powered-By%3A+PleskLin+title%3Adefault

Password 1234

    https://www.shodan.io/search?query=password="1234"

Open Netdata Dashboard

    https://www.shodan.io/search?query=http.html%3A%27netdata%27

default password

    https://www.shodan.io/search?query="default+password"

Print server - Samsung

    https://www.shodan.io/search?query=SyncThru+%22HTTP%2F1.1+200+OK%22

Admin / 1234

    https://www.shodan.io/search?query=name%3Aadmin+password%3A1234

Redis

    https://www.shodan.io/search?query=port%3A+6379

Routers passw 1234

    https://www.shodan.io/search?query=%22password+1234%22

Default admin / 1234

    https://www.shodan.io/search?query=basic+realm+%3D%22default%3A+admin%2F1234%22

OpenNMS

    https://www.shodan.io/search?query=opennms

default JSON server

    https://www.shodan.io/search?query=%22You%27re+successfully+running+JSON+Server%22

default password ip camera

    https://www.shodan.io/search?query=HTTP%2F1.1+401+Unauthorized+Connection%3A+close+Cache-Control%3A+no-cache%2Cno-store+WWW-Authenticate%3A+Basic+realm%3D%22index.html%22

Telnet 1234

    https://www.shodan.io/search?query=input+password+%28defaul+1234%29

SonarQube:Exposed Source Code

    https://www.shodan.io/search?query=country%3A%22IN%22+http.html%3A%22sonarqube%22

Loxone Smart House

    https://www.shodan.io/search?query=loxone

RT-N13U port:23

    https://www.shodan.io/search?query=RT-N13U+port%3A23

basic realm:"default"

    https://www.shodan.io/search?query=basic+realm%3D%22default%22

basic realm admin:1234

    https://www.shodan.io/search?query=Basic+realm%3D+%22+Default+name%3Aadmin+password%3A+1234%22

ExecqVision

    https://www.shodan.io/search?query=Country%3A%22US%22+http.status%3A%22200%22+http.title%3A%22index+of+%2F%22+server%3A%22%28win32%29%22+http.favicon.hash%3A476213314

DVR default

    https://www.shodan.io/search?query=dvrdvs-webs

Unprotected - Cloud torrent Instances

    https://www.shodan.io/search?query=http.favicon.hash%3A628009337

Linksys Router

    https://www.shodan.io/search?query=Linksys+WAG120N

Routers providing admin pwd

    https://www.shodan.io/search?query=Default%3A%2Badmin

pwd in banner

    https://www.shodan.io/search?query=%22default+password%22

Delta Networks Inc 

    https://www.shodan.io/search?query=delta

Router w/Default Info 

    https://www.shodan.io/search?query=admin%2B1234

Cisco IOS Servers with SSH

    https://www.shodan.io/search?query=%22cisco+cp%22

Gigaset default creds

    https://www.shodan.io/search?query=title%3A%22Gigaset+SX682+WiMAX%22

default creds

    https://www.shodan.io/search?query=Basic+realm%3D%22Default%3A+admin%2Fadmin%22

Asus Router

    https://www.shodan.io/search?query=rt-n12e

mobinet IRAN

    https://www.shodan.io/search?query=%22default+password%22+org%3A%22Wimax+-+ZTE+New+Area%22

Austrian A1 Router

    https://www.shodan.io/search?query=%22Server%3A+ADB+Broadband+HTTP+Server%22+country%3Aat+http.title%3A%22WLAN+Box%22

Smart Plug

    https://www.shodan.io/search?query=NET-PwrCtrl

Digital Watching NVR

    https://www.shodan.io/search?query=Server%3A+lighttpd%2F1.4.49+Content-Type%3A+text%2Fhtml+Content-Length%3A+689

Sicon-8 web controlers

    https://www.shodan.io/search?query=sicon-8

Alied telesyn equipment

    https://www.shodan.io/search?query=allied+telesys+port%3A23

Raspbian

    https://www.shodan.io/search?query=port%3A22+raspbian

AP WiFi Teldat

    https://www.shodan.io/search?query=%22HTTP+Server+version+2.0+-+TELDAT+S.A.%22+http.title%3A%22wifi%22

Mobinet td-lte default pwd

    https://www.shodan.io/search?query=mobinnet+port%3A%22443%22

Solar Inverters

    https://www.shodan.io/search?query=Server%3A+Sunny+WebBox+country%3A%22ES%22

bank 

    https://www.shodan.io/search?query=kenya+country%3AKE+org%3A%22Safaricom%22



## TAG : IOT

Chromecast port 8008

    https://www.shodan.io/search?query=Chromecast+port%3A%228008%22

Lantronix

    https://www.shodan.io/search?query=Lantronix+-%22secured%22+%2B%22Password%3A%22

ST950   

    https://www.shodan.io/search?query=ST950

Saferoads VMS

    https://www.shodan.io/search?query=Saferoads+VMS

Chromecast

    https://www.shodan.io/search?query=chromecast

UniFi

    https://www.shodan.io/search?query=http.title%3A%22UniFi+SDN%22

Port 515

    https://www.shodan.io/search?query=port%3A515

favicon

    https://www.shodan.io/search?query=port%3A9080+http.favicon.hash%3A902521196

c-beam telemetry

    https://www.shodan.io/search?query=title%3A%22c-beam+telemetry+server%22

jung

    https://www.shodan.io/search?query=title%3A%22jung+knx%22

ARM

    https://www.shodan.io/search?query=ARM

Ares

    https://www.shodan.io/search?query=Ares+port%3A%228080%22

X-Blackboard

    https://www.shodan.io/search?query=X-Blackboard-product%3A+Blackboard+Learn

Aics

    https://www.shodan.io/search?query=category%3Aics+-http+-html+-ssh+-notice

ikettle

    https://www.shodan.io/search?query=ikettle

Allegro

    https://www.shodan.io/search?query=port%3A8090+Allegro-Software-RomPager%2F5.40b1

GPRS Tunneling

    https://www.shodan.io/search?query=product%3A%22GPRS+Tunneling+Protocol%22

WeMo Link

    https://www.shodan.io/search?query=product%3A%22WeMo+Link%22

Jeedom

    https://www.shodan.io/search?query=title%3A%22Jeedom%22

insteon

    https://www.shodan.io/search?query=title%3A%22powered+by+insteon%22

P-660HW-T1 v3

    https://www.shodan.io/search?query=%22P-660HW-T1+v3%22

Original Siemens Equipment 

    https://www.shodan.io/search?query=Original+Siemens+Equipment

not_found

    https://www.shodan.io/search?query=html%3A%22File+%2F+not_found%22+port%3A80

hue personal wireless

    https://www.shodan.io/search?query=http.title%3A%22hue+personal+wireless+lighting%22

ozw

    https://www.shodan.io/search?query=name%3Dozw

Siemens

    https://www.shodan.io/search?query=port%3A102+siemens

MIRAI

    https://www.shodan.io/search?query=MIRAI

evChallenge

    https://www.shodan.io/search?query=port%3A9999+evChallenge

Centrale Pragma

    https://www.shodan.io/search?query=title%3A%22Centrale%22+%22Pragma%3A+no-cache%2C+no-store%22

Switched Rack

    https://www.shodan.io/search?query=%22Switched+Rack+PDU%22

Creston

    https://www.shodan.io/search?query=Crestron+PYNG-HUB

Playstation4

    https://www.shodan.io/search?query=os%3A%22playstation+4%22

Home Sweet Home

    https://www.shodan.io/search?query=html%3A%22Home%2C+Sweet+Home%22+html%3A%22fhem%22

Port 7547

    https://www.shodan.io/search?query=port%3A%227547%22

Boa

    https://www.shodan.io/search?query=product%3A%22Boa%22

Dahua

    https://www.shodan.io/search?query=product%3Adahua

WebiOpi

    https://www.shodan.io/search?query=webiopi

WireGate

    https://www.shodan.io/search?query=wiregate

MQTT

    https://www.shodan.io/search?query=%22MQTT+Connection+Code%3A+0%22+set+-alarm

Moxa

    https://www.shodan.io/search?query=%22Moxa+Nport+Device%22+Status%3A+Authentication+disabled+port%3A%224800%22

Netatmo Welcome

    https://www.shodan.io/search?query=P372+port%3A%2223%22

VNC

    https://www.shodan.io/search?query=has_screenshot%3A%22true%22+product%3A%22VNC%22+%22authentication+disabled%22

hash:-704822131 port:"53413"

    https://www.shodan.io/search?query=hash%3A-704822131+port%3A%2253413%22

Heatmiser Wifi Thermostat

    https://www.shodan.io/search?query=title%3A%22Heatmiser+Wifi+Thermostat%22

ICY Clever Thermostat

    https://www.shodan.io/search?query=title%3A%22ICY+Clever+Thermostat%22

Thermostat IP console

    https://www.shodan.io/search?query=title%3A%22Status+%26amp%3B+Control%22

Welcome on console

    https://www.shodan.io/search?query=%22%5B1m%5B35mWelcome+on+console%22

xfinity router 

    https://www.shodan.io/search?query=html%3A%22xfinity%22

UCoS

    https://www.shodan.io/search?query=ucos


## TAG : WEB


Webcam Road Runner 

    https://www.shodan.io/search?query=Server%3A+SQ-WEBCAM+org%3A%22Road+Runner%22+city%3A%22Columbus%22+port%3A80

PHPmyAdmin

	https://www.shodan.io/search?query=Server%3A+phpmyadmin+country%3AMY

Apache     

	https://www.shodan.io/search?query=apache

Web interface

    https://www.shodan.io/search?query=title%3A%22web+interface%22

Xerox

    https://www.shodan.io/search?query=http.title%3A%22Internet+Services%22+http.html%3A%22hdstat.htm%22

DVR Camera 

    https://www.shodan.io/search?query=web+remote+viewer

Network spy

    https://www.shodan.io/search?query=uc-httpd

Spark View

    https://www.shodan.io/search?query=title%3A%22Spark+View%22

Webinterface to Printers

    https://www.shodan.io/search?query=port%3A%22631%22+%22200+OK%22

Deluge webUI

    https://www.shodan.io/search?query=title%3A%22deluge%22

Torrent

    https://www.shodan.io/search?query=Torrent+HTTP%2F1.0+200+OK

Managers

    https://www.shodan.io/search?query=%22%2Fhtml%2Fmanager%22

WebRelay

    https://www.shodan.io/search?query=title%3A%22webrelay%22

Webserver Backups

    https://www.shodan.io/search?query=http.html%3A%27backup.zip%27

Pwd Protected Directories - Iran

    https://www.shodan.io/search?query=country%3Air+port%3A80+title%3Aprotected

Web cam

    https://www.shodan.io/search?query=MJPG-Streamer+200

Unprotected - Cloud Torrent Instances

    https://www.shodan.io/search?query=http.favicon.hash%3A628009337

Openstage IP phone

    https://www.shodan.io/search?query=title%3A%22openstage%22

ASP.Net Web API - Precise

    https://www.shodan.io/search?query=Content-Length%3A+3308+X-Powered-By%3A+ASP.NET

VirtualBox

    https://www.shodan.io/search?query=title%3A%22phpvirtualbox%22

Tor Markets

    https://www.shodan.io/search?query=html%3A%22tor%22+html%3A%22market%22

CDM-570LL-Band Satellite Modem

    https://www.shodan.io/search?query=port%3A161+CDM-570L+L-Band+Satellite+Modem

ARC-WEB by Symetrix

    https://www.shodan.io/search?query=title%3AARC-WEB

Printers with Telnet

    https://www.shodan.io/search?query=device%3Aprinter+port%3A23

Python HTTP Server

    https://www.shodan.io/search?query=product%3A%22SimpleHTTPServer%22

cisco elnet web

    https://www.shodan.io/search?query=cisco+port%3A23%2C80

French internet distributor

    https://www.shodan.io/search?query=numericable

web config lexmark printers

    https://www.shodan.io/search?query=Printer+Type%3A+Lexmark

web config hp printers

    https://www.shodan.io/search?query=%22Server%3A+Virata-EmWeb%22+hp

Sicon-8 Web Controllers

    https://www.shodan.io/search?query=sicon+web+controller

Printers Using Web Image Monitor

    https://www.shodan.io/search?query=port%3A514%2C+lanier

Timhillone Viewer

    https://www.shodan.io/search?query=web+cam+country%3AUS

QOS Web Login Portal

    https://www.shodan.io/search?query=title%3A%22QOS+Web%22

Juniper Web Device Manager

    https://www.shodan.io/search?query=title%3A%22Juniper+Web+Device+Manager%22

Akamai Global Hosts

    https://www.shodan.io/search?query=port%3A80+AkamaiGHost

webcam russ

    https://www.shodan.io/search?query=admin%2B1234+country%3ARU

Tor deanonymization

    https://www.shodan.io/search?query=html%3A%22.onion%22+html%3A%22hidden%22

ruTorrent Web

    https://www.shodan.io/search?query=200+rtorrent.js+add

Honeypots

    https://www.shodan.io/search?query=apache+iis

Print Server Web

    https://www.shodan.io/search?query=PRINT_SERVER+WEB+%2B200+-401+-NeedPassword

Tuxedo Connected Controller

    https://www.shodan.io/search?query=threadx+-401+-login

HeatMiser Netmonitor

    https://www.shodan.io/search?query=Z-World+Rabbit+title%3ANetmonitor
