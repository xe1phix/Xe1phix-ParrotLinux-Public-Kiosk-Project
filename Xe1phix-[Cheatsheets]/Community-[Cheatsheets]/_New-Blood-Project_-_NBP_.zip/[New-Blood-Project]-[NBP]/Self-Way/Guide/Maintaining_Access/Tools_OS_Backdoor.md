# OS Backdoors tools

    1. [Backdoor Factory](https://binject.github.io/backdoorfactory) (bettercap extension that is written in golang) -> [Github Repo](https://github.com/Binject/backdoorfactory)
    2. [Backdoor Factory written in Python](https://github.com/secretsquirrel/the-backdoor-factory)
    3. [BDFProxy](https://github.com/secretsquirrel/BDFProxy)
    4. [BetterBackdoor](https://github.com/thatcherclough/BetterBackdoor) (Written in Java but the name implies that it has more features)
    5. [CryptCat](http://cryptcat.sourceforge.net/) && [Sourceforge](https://sourceforge.net/projects/cryptcat/) && [Github Repo](https://github.com/pprugger/Cryptcat-1.3.0-Win-10-Release)
    6. [DBD (Netcat clone with encryption)](https://github.com/gitdurandal/dbd)
    7. [SBD (Secure BackDoor)](http://mirrors.kernel.org/gentoo/distfiles/sbd-1.37.tar.gz)
    8. [cymothoa](http://cymothoa.sourceforge.net)
    9. [tsh (Tiny SHell)](https://github.com/creaktive/tsh) && (https://github.com/int0x33/tsh)
    10. [SharPersit](https://github.com/fireeye/SharPersist) -> [Documentation](https://github.com/fireeye/SharPersist/wiki) && [Blog Post](https://www.fireeye.com/blog/threat-research/2019/09/sharpersist-windows-persistence-toolkit.html)
    11. [Backoori](https://github.com/giuliocomi/backoori)
    12. [SSHPry2.0](https://github.com/nopernik/SSHPry2.0)
    13. [Javascript-Obfuscator](https://github.com/javascript-obfuscator/javascript-obfuscator)
    14. [Beelogger](https://github.com/4w4k3/BeeLogger)
    15. [Keylogger](https://github.com/GiacomoLaw/Keylogger)
    16. [avKeylogger](https://github.com//fuckwbored/avKeylogger)
    17. [sudo-SCAM](https://github.com/TheOddZer0/sudo-SCAM)

> Taken from https://github.com/ghostsec420/SCPA
