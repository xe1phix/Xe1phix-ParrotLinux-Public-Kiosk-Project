# Web Backdoors tools

    1. [laudanum](http://laudanum.inguardians.com/#)
    2. [webacoo](https://bechtsoudis.com/webacoo/)
    3. [weevely](https://github.com/epinna/weevely3) -> [Documentation](https://github.com/epinna/weevely3/wiki)
    4. [PHPSploit](https://github.com/nil0x42/phpsploit)
    5. [SecurityNotFound](https://github.com/CosasDePuma/SecurityNotFound)
    6. [bantam](https://github.com/gellin/bantam)
    7. [SharPyShell](https://github.com/antonioCoco/SharPyShell)
    8. [PHPBash](https://github.com/Arrexel/phpbash)

> Taken from https://github.com/ghostsec420/SCPA
