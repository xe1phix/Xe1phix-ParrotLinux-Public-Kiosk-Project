# Reversing

**Some tools from command line**

**apktool**
* tool for reverse engineering Android apk files

**bytecode-viewer**
* Java 8+ Jar & Android APK Reverse Engineering Suite

**ferret**
* CASE tool for data model editing

**ghidra**
* Software Reverse Engineering Framework

**miller**
* name-indexed data processing tool

**rarpd**
* Reverse Address Resolution Protocol daemon

**rizin**
* reverse engineering framework and command-line toolset

**rizin-cutter**
* reverse engineering platform powered by rizin

