Name, URL, Description
Dehashed,https://www.dehashed.com/,View leaked credentials
SecurityTrails,https://securitytrails.com/,Extensive DNS data
DorkSearch—Really,https://dorksearch.com/,Really fast Google dorking
ExploitDB,https://www.exploit-db.com/,Archive of various exploits
ZoomEye,https://www.zoomeye.org/project?id=firewall,Gather information about targets
Pulsedive—Search,https://pulsedive.com/,Search for threat intelligence
GrayHatWarefare,https://buckets.grayhatwarfare.com/,Search public S3 buckets
PolySwarm,https://polyswarm.io/,Scan files and URLs for threats
Fofa,https://github.com/wgpsec/fofa_viewer,Search for various threat intelligence
LeakIX,https://leakix.net/,Search publicly indexed information
DNSDumpster,https://dnsdumpster.com/,Search for DNS records quickly
FullHunt,https://fullhunt.io/,Search and discovery attack surfaces
AlienVault,https://otx.alienvault.com/,Extensive threat intelligence feed
ONYPHE,https://www.onyphe.io/,Collects cyber-threat intelligence data
Grep App,https://grep.app/,Search across a half million git repos
URL Scan,https://urlscan.io/,Free service to scan and analyse websites
Vulners,https://vulners.com/,Search vulnerabilities in a large database
WayBackMachine,https://archive.org/web/,View content from deleted websites
Shodan—View,https://www.shodan.io/,Search for devices connected to the internet
Netlas,https://netlas.io/,Search and monitor internet connected assets
CRT Certificate Search,https://crt.sh/,Search for certs that have been logged by CT
Wigle,https://www.wigle.net/,Database of wireless networks with statistics
PublicWWW,https://publicwww.com/,Marketing and affiliate marketing research
DNSLytics,https://dnslytics.com/reverse-analytics,Find domains sharing the same Analytics ID
Binary Edge,https://www.binaryedge.io/,Scans the internet for threat intelligence
GreyNoise,https://www.greynoise.io/,Search for devices connected to the internet
Hunter,https://hunter.io/,Search for email addresses belonging to a website
Censys,https://censys.io/,Assessing attack surface for internet connected devices
IntelligenceX,https://intelx.io/,Search Tor/I2P/data leaks/domains/emails
Packet Storm Security,https://packetstormsecurity.com/,Browse latest vulnerabilities and exploits
SearchCode,https://searchcode.com/,Search 75 billion lines of code from 40 million projects
SpyOnWeb,https://spyonweb.com/,Find out related websites
OpenPhish,https://openphish.com/,Relevant Phishing Intelligence
PhishStats,https://phishstats.info/,sharing phishing information