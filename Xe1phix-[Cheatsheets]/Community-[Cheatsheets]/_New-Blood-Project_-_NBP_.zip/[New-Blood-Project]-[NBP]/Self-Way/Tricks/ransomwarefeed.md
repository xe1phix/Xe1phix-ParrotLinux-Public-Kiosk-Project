Ransomware Name, URL, Status
AVADDON,http://avaddongun7rngel.onion/,Online
SODINOKIBI (REVIL),http://dnpscnbaix6nkwvystl3yxglz7nteicqrou3t75tpcc5532cztc46qyd.onion/,Online
NEFILIM,http://hxt254aygrsziejn.onion/,Online
VFOKX (1),http://vfokxcdzjbpehgit223vzdzwte47l3zcqtafj34qrr26htjo4uf3obid.onion/,Online
VFOKX (2),http://746pbrxl7acvrlhzshosye3b3udk4plurpxt2pp27pojfhkkaooqiiqd.onion/,Online
MARKETO (deep),https://marketo.cloud/,Online
MARKETO (dark),http://g5sbltooh2okkcb2.onion/,Online
LORENZ,http://lorenzmlwpzgxq736jzseuterytjueszsvznuibanxomlpkyxk6ksoyd.onion/,Online
CONTI/RYUK,http://continewsnv5otx5kaoje7krkto2qbu3gtqef22mnr7eaxw3y6ncz3ad.onion/,Online
RANSOMEXX,http://rnsm777cdsjrsdlbs4v5qoeppu3px6sb2igmh53jzrx7ipcrbjz5b2ad.onion/,Online
SynACK,http://xqkz2rmrqkeqf6sjbrb47jfwnqxcd4o2zvaxxzrpbh2piknms37rw2ad.onion/,Online
PAYLOD.BIN (EX BABUK LOCKER),http://wavbeudogz6byhnardd2lkp2jafims3j7tj6k6qnywchn2csngvtffqd.onion/,Online
DARKSIDE,http://darksidc3iux462n6yunevoag52ntvwp6wulaz3zirkmh4cnz6hhj7id.onion/,Online
CLOP,http://ekbgzchl6x2ias37.onion/,Online
MOUNT LOCKER,http://mountnewsokhwilx.onion/,Online
PYSA,http://pysa2bitc5ldeyfak4seeruqymqs4sj5wt5qkcq7aoyg4h2acqieywad.onion/partners.html,Online
ASTROTEAM,http://anewset3pcya3xvk73hj7yunuamutxxsm5sohkdi32blhmql55tvgqad.onion/,Online
SUNCRYPT,http://nbzzb6sa6xuura2z.onion/,Online
PAY2KEY,http://pay2key2zkg7arp3kv3cuugdaqwuesifnbofun4j6yjdw5ry7zw2asid.onion/,Online
EVEREST,http://ransomocmou6mnbquqz44ewosbkjk3o5qjsl3orawojexfook2j7esad.onion/,Online
RANZY/AKO,http://37rckgo66iydpvgpwve7b2el5q2zhjw4tv4lmyewufnpx4lhkekxkoqd.onion/,Online
CUBA,http://cuba4mp6ximo2zlo.onion/,Online
RAGNAROK,http://wobpitin77vdsdiswr43duntv6eqw4rvphedutpaxycjdie6gg3binad.onion/,Online
RAGNAR LOCKER (old),http://ragnarleaks.top/,Online
RAGNAR LOCKER,http://p6o7m73ujalhgkiv.onion/,Online
EGREGOR,https://egregornews.com/,Online
MAZE,https://newsmaze.net/,Online
LV (1),http://rbvuetuneohce3ouxjlbxtimyyxokb4btncxjbo44fbgxqy7tskinwad.onion,Online
LV (2),http://4qbxi3i2oqmyzxsjg4fwe4aly3xkped52gq5orp6efpkeskvchqe27id.onion/,Online
XING LOCKER,http://xingnewj6m4qytljhfwemngm7r7rogrindbq7wrfeepejgxc3bwci7qd.onion/,Online
LOCKBIT,http://lockbitkodidilol.onion/,Online
BLACK SHADOW,http://544corkfh5hwhtn4.onion/,Online
N3TW0RM,http://n3twormruynhn3oetmxvasum2miix2jgg56xskdoyihra4wthvlgyeyd.onion/,Online
HADES,http://ixltdyumdlthrtgx.onion/,Online
DOPPLE PAYMER,http://hpoo4dosa3x4ognfxpqcrjwnsigvslm7kv6hvmhh2yqczaxy3j6qnwad.onion/,Online
RANSOMWARE GROUP SITES (list),http://thexfvx7hqcrpgtm.onion/,Online
PROMETHEUS,http://promethw27cbrcot.onion/blog/,Online
GRIEF,http://griefcameifmv4hfr3auozmovz5yi6m3h3dwbuqw7baomfxoxz4qteid.onion,Online
NEMTY,http://nemty.top,Online
SEKHMET,http://sekhmet.top,Online
NETWALKER,rnfdsgm6wb6j6su5txkekw4u4y47kp2eatvu7d6xhyn5cs4lt4pdrqqd.onion,Online
LOCKBIT 2.0,http://Lockbitapt6vx57t3eeqjofwgcglmutr3a35nygvokja5uuccip4ykyd.onion,Online
HIVE,http://hiveleakdbtnp76ulyhi52eag6c6tyc3xw7ez7iqy6wc34gd2nekazyd.onion/,Online
VICE SOCIETY,http://4hzyuotli6maqa4u.onion,Online