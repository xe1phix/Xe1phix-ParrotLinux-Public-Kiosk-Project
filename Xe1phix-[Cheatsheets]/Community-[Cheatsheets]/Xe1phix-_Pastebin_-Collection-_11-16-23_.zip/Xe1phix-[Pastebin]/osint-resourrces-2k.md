OSINT Resource Tool Kit

"""
Credit:
paranoid_ch1ck
0PT1C
"""

OSINT Links 






  # Collections / Tools

  *
    Awesome OSINT 2
    <https://github.com/Ph055a/awesome_osint>
  *
    Bellingcat’s Online Investigation Toolkit
    <https://docs.google.com/document/d/1BfLPJpRtyq4RFtHJoNpvWQjmGnyVkfE2HYoICKOGguA/edit#heading=h.6igzqqftqvh4>

  *
    Booleanstring's tools
    <https://booleanstrings.com/tools/>
  *
    Bruno Mortier - GeoInt
    <https://start.me/p/W1kDAj/geoint>
  *
    Bruno Mortier - IMINT
    <https://start.me/p/ZMXLlA/imint-vi>
  *
    Bruno Mortier - Infrastructure
    <https://start.me/p/V0PXgr/infrastructure>
  *
    Bruno Mortier - Keywords
    <https://start.me/p/VvGz56/keywords>
  *
    Bruno Mortier - Monitoring
    <https://start.me/p/3xMXnP/monitoring>
  *
    Bruno Mortier - Opsec
    <https://start.me/p/ZkMLp5/opsec>
  *
    Bruno Mortier - Resources
    <https://start.me/p/WELz48/resources>
  *
    Bruno Mortier - Search Engine
    <https://start.me/p/ekl8eK/search-engines>
  *
    Bruno Mortier - Security
    <https://start.me/p/Zz4gyM/security>
  *
    Bruno Mortier - SOCMINT
    <https://start.me/p/Wp1kpe/socmint>
  *
    Bruno Mortier - Sources
    <https://start.me/p/3g0aKK/sources>
  *
    Bruno Mortier - Toolkit
    <https://start.me/p/W1AXYo/toolkit>
  *
    Bruno Mortier OSINT
    <https://start.me/p/ZME8nR/osint?locale=es>
  *
    Capteurs Ouverts - OSTER
    <https://start.me/p/7kmvEK/oster>
  *
    Covert Shores
    <http://www.hisutton.com/OSINT_Landscape.html>
  *
    CyberChef - The Cyber Swiss Army Knife
    <https://gchq.github.io/CyberChef/>
  *
    CyberTOOLBELT (PAID)
    <https://www.cybertoolbelt.com/>
  *
    DIRT
    <https://dirtdirectory.org/>
  *
    Emmanuel Welch - Dating Apps
    <https://start.me/p/VRxaj5/dating-apps-and-hook-up-sites-for-investigators>

  *
    eToolz
    <https://www.gaijin.at/en/dlet.php>
  *
    GIJC2017 doc
    <https://drive.google.com/file/d/1pLjKuNjFyHGDiOAW7sLmX7L9o2j5kdbF/view>

  *
    I-Intelligence links
    <https://www.i-intelligence.eu/de/quellen/links-de/>
  *
    IVMachiavelli Links
    <https://github.com/IVMachiavelli/OSINT_Team_Links>
  *
    Jake Creps - Social Media Intelligence Dashboard
    <https://start.me/p/m6MbeM/social-media-intelligence-dashboard>
  *
    Jk Priv - ASINT Collection
    <https://start.me/p/b5Aow7/asint_collection>
  *
    Julia Bayer - Verification Toolset
    <https://start.me/p/ZGAzN7/verification-toolset>
  *
    Kas Stoner's OSINT board
    <https://www.pinterest.com/Kas_Stoner/osint/>
  *
    Lorand Bodo - Terrorism & Radicalisation Research Dashboard
    <https://start.me/p/OmExgb/terrorism-radicalisation-research-dashboard>
  *
    Midasearch ressources
    <https://midasearch.org/>
  *
    NetBootCamp
    <https://netbootcamp.org/osinttools/>
  *
    OSINT Framework
    <http://osintframework.com/>
  *
    OSINT Master
    <https://start.me/p/MEXNOe/osint-resources-master-repository>
  *
    OSINT Resources Master Repository
    <https://start.me/p/MEXNOe/osint-resources-master-repository>
  *
    OSINT Search Tool by IntelTechniques
    <https://inteltechniques.com/menu.html>
  *
    OSINT Tools and Resources Handbook
    <https://www.i-intelligence.eu/wp-content/uploads/2018/06/OSINT_Handbook_June-2018_Final.pdf>

  *
    OSINT-Framework
    <https://github.com/lockfale/osint-framework>
  *
    osint.link
    <http://osint.link/>
  *
    Phil Bradley's links
    <http://www.philb.com/>
  *
    pygraphistry
    <https://graphistry.github.io/pygraphistry/index.html>
  *
    Research Clinic List
    <http://researchclinic.net/links.html>
  *
    Reuser's Repertorium
    <http://rr.reuser.biz/>
  *
    security-datasets
    <https://github.com/hgascon/security-datasets>
  *
    SPPR Gdrive
    <https://drive.google.com/drive/folders/0BwyWDQ59jRVGMFp3UnBfeUEzanM>
  *
    Technisette - Bellingcat OSINT
    <https://start.me/p/ELXoK8/bellingcat-osint-landscape>
  *
    Technisette - OSINT
    <https://start.me/p/m6XQ08/osint>
  *
    Threat Intel Templates
    <https://github.com/sroberts/threat-intel-templates>
  *
    Toddington Resources
    <https://www.toddington.com/resources/>
  *
    Tools | Transparency Toolkit
    <https://transparencytoolkit.org/tools/>
  *
    UK OSINT Tools
    <https://www.uk-osint.net/favorites.html>
  *
    VirusTotal Graph
    <https://www.virustotal.com/graph/>
  *
    Your OSINT Graphical Analyzer (YOGA)
    <https://yoga.osint.ninja/> 




   # Blogs / Resources

  *
    Antivirus Event Analysis Cheat Sheet v1.7
    <https://www.nextron-systems.com/2019/02/06/antivirus-event-analysis-cheat-sheet-v1-7/>

  *
    bellingcat
    <https://www.bellingcat.com/>
  *
    BlueLiv Blog
    <https://www.blueliv.com/blog-news/>
  *
    Data Detox Kit
    <https://datadetoxkit.org/en/home>
  *
    FireEye Threat Research Blog
    <https://www.fireeye.com/blog/threat-research.html>
  *
    Flashpoint Intel Blog
    <http://flashpoint-intel.com/blog>
  *
    Fortinet Threat Research Blog
    <http://fortinet.com/blog/threat-research.html>
  *
    Fox-It Blogs
    <https://fox-it.com/en/insights/blogs/>
  *
    Grey Noise Blog
    <https://greynoise.io/blog/>
  *
    Group-IB Blog
    <https://www.group-ib.com/blog/>
  *
    InfoSecSherpa
    <https://medium.com/@infosecsherpa>
  *
    IntelTechniques Blog
    <https://inteltechniques.com/blog/>
  *
    List of Intelligence Gathering Disciplines
    <https://en.wikipedia.org/wiki/List_of_intelligence_gathering_disciplines>

  *
    Looking Glass Threat Intel Blog
    <http://lookingglasscyber.com/blog/>
  *
    Open Source Intelligence Tools and Resources Handbook
    <https://www.i-intelligence.eu/wp-content/uploads/2018/06/OSINT_Handbook_June-2018_Final.pdf>

  *
    OSINT - Secjuice Infosec Writers Guild
    <https://www.secjuice.com/tag/osint/>
  *
    OSINT Blog
    <https://osintblog.io/>
  *
    Recorded Future Blog
    <https://www.recordedfuture.com/blog/>
  *
    Resources and Reading for those interested in OSINT
    <https://www.peerlyst.com/posts/so-you-wanna-osint-resources-and-reading-for-those-interested-in-osint-joe-gray>

  *
    SecurityAffairs Intelligence Archives
    <https://securityaffairs.co/wordpress/category/intelligence>
  *
    Sucuri Security
    <http://labs.sucuri.net/?notes>
  *
    SurfWatch Labs Blog
    <https://blog.surfwatchlabs.com/>
  *
    The Citizen Lab - Targeted Threats
    <https://citizenlab.ca/category/research/targeted-threats/>
  *
    ThreatConnect - Blogs/Reports
    <https://threatconnect.com/blog/ingest-technical-blogs-reports/>
  *
    Threat Hunting with Jupyter Notebooks— Part 1: Your First Notebook 📓
    <https://posts.specterops.io/threat-hunting-with-jupyter-notebooks-part-1-your-first-notebook-9a99a781fde7>

  *
    Timothy De Block's Blog
    <http://www.timothydeblock.com/>
  *
    We are OSINTCurio.us
    <https://osintcurio.us/>
  *
    Week in OSINT – Sector035
    <https://medium.com/week-in-osint> 




   # Feeds

  *
    Anomali Threatstream
    <https://www.anomali.com/>
  *
    c1fapp.com/
    <https://www.c1fapp.com/>
  *
    CIRCL (MISP feed)
    <https://www.circl.lu/doc/misp/feed-osint/>
  *
    Critical Stack Intel
    <http://intel.criticalstack.com/>
  *
    CyberCure
    <http://cybercure.ai/>
  *
    ET Intelligence
    <https://threatintel.proofpoint.com/>
  *
    FireEye - iSIGHT (PAID)
    <https://www.fireeye.com/solutions/isight-cyber-threat-intelligence-subscriptions.html>

  *
    hail a taxii
    <http://hailataxii.com/>
  *
    intelgraph.idefense.com (PAID)
    <http://intelgraph.idefense.com/>
  *
    IntelMQ - Documentation
    <https://github.com/certtools/intelmq-feeds-documentation>
  *
    Netlab OpenData Project
    <http://data.netlab.360.com/>
  *
    OpenPhish - Phishing Feeds
    <https://openphish.com/phishing_feeds.html>
  *
    OPSWAT MetaDefender Cloud | Threat Intelligence Feeds
    <https://metadefender.opswat.com/threat-intelligence-feeds>
  *
    Recorded Future TI Feeds
    <https://www.recordedfuture.com/solutions/threat-intelligence-feeds/>
  *
    rjmolesa/feeds.opml
    <https://gist.github.com/rjmolesa/db96afb10e8fc54c06d6>
  *
    Secureworks Cyber TI (PAID)
    <https://www.secureworks.com/capabilities/threat-intelligence/global-threats>

  *
    The Cyber Threat
    <http://thecyberthreat.com/cyber-threat-intelligence-feeds/>
  *
    Threat Intelligence Review
    <http://threatintelligencereview.com/>
  *
    ThreatTrack
    <https://www.threattrack.com/> 




   # How To

  *
    Google Dorking
    <http://www.google-dorking.com/>
  *
    Google Dorks - Cybrary
    <https://www.cybrary.it/0p3n/google-dorks-easy-way-of-hacking/>
  *
    Google Hacking Techniques - SecurityTrails
    <https://securitytrails.com/blog/google-hacking-techniques>
  *
    How to Perform Network Fingerprinting with Maltego
    <https://www.youtube.com/watch?v=hPIhItC-Vr8>
  *
    How to scrape websites with Python and BeautifulSoup
    <https://medium.com/free-code-camp/how-to-scrape-websites-with-python-and-beautifulsoup-5946935d93fe>

  *
    ꓘamerka — Build interactive map of cameras from Shodan
    <https://medium.com/@woj_ciech/%EA%93%98amerka-build-interactive-map-of-cameras-from-shodan-a0267849ec0a>





   # Online Investigations Tracking

  *
    Hunchly
    <https://www.hunch.ly/>
  *
    Paliscope
    <https://www.paliscope.com/>
  *
    Zotero
    <https://www.zotero.org/>
  *
    harleo/blink
    <https://github.com/harleo/blink> 




   # Podcasts

  *
    Exploring Information Security
    <http://www.timothydeblock.com/eis/>
  *
    OSINT Analyst Podcast
    <https://jakecreps.com/>
  *
    The Complete Privacy & Security Podcast
    <https://inteltechniques.com/podcast.html>
  *
    The Social-Engineer Podcast
    <https://www.social-engineer.org/category/podcast/> 




   # Organizations / Associations

  *
    FS-ISAC : Financial Services - Information Sharing and Analysis Center
    <https://www.fsisac.com/>
  *
    Intelligence and National Security Alliance
    <https://www.insaonline.org/> 




   # Reading

  *
    Book - The Cyber Threat (by Bob Gourley)
    <http://thecyberthreat.com/>
  *
    DarkReading - Threat Intel
    <https://www.darkreading.com/threat-intelligence.asp>
  *
    DEA Intelligence Report - Drug Slang Words
    <http://ndews.umd.edu/sites/ndews.umd.edu/files/dea-drug-slang-code-words-may2017.pdf>

  *
    FireEye - CurrentThreats
    <http://fireeye.com/current-threats.html>
  *
    Fox-It Papers
    <http://fox-it.com/en/insights/papers>
  *
    HackSurfer Reading
    <https://hacksurfer.com/>
  *
    Operation Blockbuster
    <https://www.operationblockbuster.com/>
  *
    Library of Free Online Books
    <https://www.questia.com/library/free-books> 




   # Search Engines

  *
    Bing
    <https://www.bing.com/>
  *
    Biznar
    <https://biznar.com/biznar/desktop/en/search.html>
  *
    Carrot2 Clustering Engine
    <http://search.carrot2.org/stable/search>
  *
    DuckDuckGo
    <https://duckduckgo.com/>
  *
    Google
    <https://www.google.com/>
  *
    Google Alerts
    <https://www.google.com/alerts>
  *
    Yahoo
    <https://www.yahoo.com/>
  *
    Yandex
    <https://yandex.com/>
  *
    Yippy
    <http://yippy.com/> 




   # Training / Cons

  *
    AutomatingOSINT.com
    <https://learn.automatingosint.com/wp-login.php>
  *
    Certified Fraud Examiner (CFE)
    <https://www.acfe.com/become-cfe-qualifications.aspx>
  *
    Certified Threat Intelligence Analyst (CTIA)
    <https://www.eccouncil.org/programs/certified-threat-intelligence-analyst-ctia/>

  *
    Google Calendar of OSINTy Events
    <https://osintcurio.us/events/>
  *
    IntelTechniques.com
    <https://inteltechniques.com/training/>
  *
    irongeek.com
    <http://www.irongeek.com/>
  *
    Packt>Free Learning
    <https://www.packtpub.com/free-learning>
  *
    Plessas - BSides NoVA 2018
    <https://www.irongeek.com/i.php?page=videos/bsidesnova2018/102-deep-dive-in-the-dark-web-osint-style-kirby-plessas>

  *
    PluralSight - OSINT Training
    <https://app.pluralsight.com/id?>
  *
    SecKC - Kansas City InfoSec Meetup
    <https://seckc.org/> 



   # APT

  *
    APT Groups and Operations
    <https://docs.google.com/spreadsheets/u/1/d/1H9_xaxQHpWaa4O_Son4Gx0YOIzlcBWMsdvePFX68EKU/pubhtml>

  *
    APT & Malware Related Custom Search
    <https://gist.github.com/Neo23x0/c4f40629342769ad0a8f3980942e21d3>
  *
    kbandla/APTnotes
    <https://github.com/kbandla/APTnotes> 




   # Bitcoin

  *
    Bitcoin Block Explorer - Blockchain
    <https://www.blockchain.com/explorer>
  *
    WalletExplorer
    <https://www.walletexplorer.com/> 




   # Business Search

  *
    Arachnys Solutions /INVESTIGATOR
    <https://www.arachnys.com/solutions/investigator>
  *
    B2B Contact Database (PAID)
    <https://www.zoominfo.com/>
  *
    CharityNavigator
    <https://www.charitynavigator.org/index.cfm?bay=search.advanced>
  *
    D&B Hoovers
    <http://hoovers.com/>
  *
    GuideStar
    <https://www.guidestar.org/search#>
  *
    Jigsaw
    <https://jigsaw.com/>
  *
    SMWYG (Show-Me-What-You-Got)
    <https://github.com/Viralmaniar/SMWYG-Show-Me-What-You-Got>
  *
    BuiltWith
    <https://builtwith.com/> 




   # Court Records

  *
    PacerMonitor
    <https://www.pacermonitor.com/>
  *
    PACER Case Locator
    <https://pcl.uscourts.gov/pcl/index.jsf> 




   # CVE Info

  *
    CVE-Search
    <https://cve.circl.lu/>
  *
    CVE - Common Vulnerabilities and Exposures
    <http://cve.mitre.org/>
  *
    Vfeed.io - Free Community Edition
    <https://vfeed.io/pricing/> 




   # CyberCrime

  *
    ActorTrackr
    <https://actortrackr.com/>
  *
    APT Groups, Operations and Malware Search Engine
    <https://cse.google.com/cse/publicurl?cx=003248445720253387346:turlh5vi4xc>

  *
    Cyber Campaigns
    <http://cybercampaigns.net/>
  *
    Shadowserver Foundation
    <https://shadowserver.org/wiki/> 




   # eCommerce

  *
    JungleScam
    <https://github.com/pielco11/JungleScam> 




   # Email / Username

  *
    Check Usernames
    <http://checkusernames.com/>
  *
    Citadel
    <http://citadel.pw/>
  *
    Clearbit
    <https://connect.clearbit.com/>
  *
    gaijin
    <https://www.gaijin.at/en/olsmailheader.php>
  *
    GSuite Toolbox Messageheader
    <https://toolbox.googleapps.com/apps/messageheader/analyzeheader>
  *
    Have I been pwned?
    <https://haveibeenpwned.com/>
  *
    IPTrackerOnline
    <https://www.iptrackeronline.com/email-header-analysis.php>
  *
    Leak - Lookup
    <https://leak-lookup.com/>
  *
    Mail Header Analyzer (MHA)
    <https://mailheaderanalyzer.herokuapp.com/>
  *
    Pipl
    <https://pipl.com/>
  *
    Scythe Framework
    <http://blog.c22.cc/2012/10/03/scythe-framework> 




   # Hashing

  *
    [EN|DE]CRYPT HASH
    <https://md5hashing.net/hash>
  *
    SANS ISC: Reverse Hash Calculator
    <https://isc.sans.edu/tools/reversehash.html> 




   # Honeypot Stuff

  *
    foospidy/HoneyPy
    <https://github.com/foospidy/HoneyPy>
  *
    HoneyDB
    <https://riskdiscovery.com/honeydb/>
  *
    leeberg/BlueHive
    <https://github.com/leeberg/BlueHive>
  *
    Project HoneyPot
    <https://www.projecthoneypot.org/> 




   # IoT

  *
    BinaryEdge
    <https://www.binaryedge.io/>
  *
    kamerka
    <https://github.com/woj-ciech/kamerka>
  *
    Shodan
    <https://www.shodan.io/> 




   # Legal

  *
    case.law
    <https://case.law/>
  *
    Humanitarian Law & Policy Blog
    <https://blogs.icrc.org/law-and-policy/> 




   # Maritime / Radio

  *
    AIS Data Sources
    <https://mods.marin.nl/display/MIOD/AIS+Data+Sources>
  *
    Find Old Amateur Radio Call Signs
    <http://w0is.com/oldcallsigns/oldcalls.html> 




   # Misc

  *
    ATT&CK™ Navigator - Enterprise
    <https://mitre.github.io/attack-navigator/enterprise/>
  *
    ATT&CK™ Navigator - Mobile
    <https://mitre.github.io/attack-navigator/mobile/>
  *
    mitre/attack-navigator
    <https://github.com/mitre/attack-navigator>
  *
    UserAgentString
    <http://useragentstring.com/> 




   # Multimedia - Research

  *
    Stolen Camera Finder
    <https://www.stolencamerafinder.com/>
  *
    TinEye Reverse Image Search
    <https://tineye.com/>
  *
    Yandex Search - Image / Reverse Image
    <https://yandex.com/images/> 




   # Online Records Search

  *
    Black Book Online
    <https://www.blackbookonline.info/>
  *
    BRB Publications
    <http://brbpublications.com/>
  *
    CLEAR Investigation Software (PAID)
    <https://legal.thomsonreuters.com/en/products/clear-investigation-software>

  *
    IRBSearch (PAID)
    <https://irbsearch.com/>
  *
    LexisNexis Public Records Search (PAID)
    <https://www.lexisnexis.com/en-us/products/public-records.page>
  *
    LexisNexis® Accurint® (PAID)
    <http://www.accurint.com/>
  *
    Locate PLUS - Skip Tracing (PAID)
    <https://locateplus.com/>
  *
    MicroBilt (PAID)
    <https://www.microbilt.com/category/background-screening>
  *
    Search Systems
    <http://publicrecords.searchsystems.net/>
  *
    SearchTempest (Online Auctions)
    <https://www.searchtempest.com/>
  *
    Tracers (PAID)
    <https://www.tracersinfoonline.com/en/>
  *
    Factiva - Global News (PAID)
    <https://www.dowjones.com/products/factiva/>
  *
    LexisNexis Searchable Directory (PAID)
    <http://w3.nexis.com/sources/>
  *
    ProQuest
    <https://www.proquest.com/connect/> 




   # People Search

  *
    Classmates
    <https://www.classmates.com/>
  *
    Degree Verification
    <https://nscverifications.org/welcome-to-verification-services/>
  *
    FullContact
    <https://www.fullcontact.com/>
  *
    International- Infobel Directory
    <https://www.infobel.com/>
  *
    Littlesis
    <https://littlesis.org/>
  *
    MarketVisual Search
    <http://marketvisual.com/>
  *
    Myspace
    <https://myspace.com/>
  *
    PeekYou
    <https://www.peekyou.com/>
  *
    Search for People, Businesses and Places
    <https://www.192.com/>
  *
    SMWYG (Show-Me-What-You-Got)
    <https://github.com/Viralmaniar/SMWYG-Show-Me-What-You-Got>
  *
    Spokeo
    <https://www.spokeo.com/>
  *
    TLOxp (PAID)
    <https://www.tlo.com/searches-and-reports>
  *
    Trape v2.0
    <https://www.kitploit.com/2018/11/trape-v20-people-tracker-on-internet.html?amp=0>

  *
    UK - Search for People, Businesses and Places
    <https://www.192.com/>
  *
    US Search
    <https://www.ussearch.com/>
  *
    UserSearch
    <https://usersearch.org/>
  *
    VoteWithMe
    <https://votewithme.us/>
  *
    xillwillx/skiptracer
    <https://github.com/xillwillx/skiptracer> 




   # Social Media Research

  *
    birdwatcher
    <https://github.com/michenriksen/birdwatcher>
  *
    Echosec Systems Ltd (PAID)
    <https://app.echosec.net/login>
  *
    Facebook Matrix - Plessas.net
    <https://plessas.net/facebookmatrix>
  *
    facebookmatrix
    <https://docs.google.com/spreadsheets/d/15dD0qSCDYDwVtWKC9zfZk1j8RzmvZARXTu9hrM34DnU/edit#gid=0>

  *
    Geofeedia (PAID)
    <https://www.geofeedia.com/>
  *
    Instagram-Crawler
    <https://github.com/hehpollon/Instagram-crawler>
  *
    InstaLoader
    <https://instaloader.com/>
  *
    KnowEm
    <https://knowem.com/>
  *
    Lullar
    <http://www.lullar.com/>
  *
    Namechk
    <https://namechk.com/>
  *
    Social Mention
    <http://socialmention.com/>
  *
    Social Mention
    <http://socialmention.com/>
  *
    Socilab - LinkedIn Visualization
    <http://socilab.com/#home>
  *
    Stalkscan (Facebook Scanner)
    <https://stalkscan.com/>
  *
    The one million tweet map
    <https://onemilliontweetmap.com/>
  *
    tinfoleak
    <https://tinfoleak.com/>
  *
    Tweet Archivist (PAID)
    <http://www.tweetarchivist.com/>
  *
    TweetBeaver - Home of Really Useful Twitter Tools
    <https://tweetbeaver.com/>
  *
    TweetDeck
    <https://tweetdeck.twitter.com/>
  *
    Twitter Scraper
    <https://github.com/taspinar/twitterscraper>
  *
    Twitter Trending Hashtags and Topics
    <https://www.trendsmap.com/>
  *
    ꓘamerka 2.0 (aka FIST)
    <https://github.com/woj-ciech/kamerka> 




   # Spam

  *
    SpamCop
    <https://www.spamcop.net/bl.shtml>
  *
    SpamHaus
    <https://www.spamhaus.org/> 






   # Dark Web Resources / Info

  *
    Dark Owl (Darknet resources)
    <https://www.darkowl.com/>
  *
    Deep-Explorer
    <https://github.com/blueudp/Deep-Explorer>
  *
    TorBot - Dark Web OSINT Tool
    <https://github.com/DedSecInside/TorBoT>
  *
    Torhiddenwiki.com
    <https://torhiddenwiki.com/> 




   # Domain / IP Research

  *
    Alexa Top 1 Million sites
    <http://s3.amazonaws.com/alexa-static/top-1m.csv.zip>
  *
    Apility
    <https://apility.io/>
  *
    archive.today
    <https://archive.fo/>
  *
    AutoShun by RiskAnalytics
    <https://www.autoshun.org/>
  *
    bgp.he.net
    <https://bgp.he.net/>
  *
    BLACKLISTALERT.ORG
    <http://blacklistalert.org/>
  *
    Blacklisted IP check
    <https://whoisip.ovh/blacklist>
  *
    Blocklist
    <https://www.blocklist.de/lists/>
  *
    botvrij.eu - powered by MISP
    <http://botvrij.eu/>
  *
    Censys
    <https://censys.io/>
  *
    check.torproject.org/cgi-bin/TorBulkExitList.py?ip=1.1.1.1
    <https://check.torproject.org/cgi-bin/TorBulkExitList.py?ip=1.1.1.1>
  *
    CINSscore.com
    <http://cinsscore.com/>
  *
    cinsscore.com/list/ci-badguys.txt
    <http://cinsscore.com/list/ci-badguys.txt>
  *
    CIRCL » BGP Ranking
    <http://circl.lu/projects/bgpranking/>
  *
    Cisco Umbrella Popularity List
    <https://s3-us-west-1.amazonaws.com/umbrella-static/index.html>
  *
    Deep Magic
    <https://deepmagic.com/>
  *
    DNS-Trails
    <http://securitytrails.com/dns-trails>
  *
    DNS2IP
    <http://dns2ip.info/>
  *
    DNSdumpster.com
    <https://dnsdumpster.com/>
  *
    DNSlytics
    <https://dnslytics.com/tools>
  *
    DNSQueries - Network Tools
    <https://www.dnsqueries.com/en/>
  *
    domainIQ
    <https://www.domainiq.com/>
  *
    domainIQ - Historical Zone Files
    <https://www.domainiq.com/tools_zone>
  *
    Down For Everyone Or Just Me
    <https://downforeveryoneorjustme.com/>
  *
    ExoneraTor
    <https://metrics.torproject.org/exonerator.html>
  *
    FraudGuard.io
    <https://app.fraudguard.io/login>
  *
    Free Blocklists of Suspected Malicious IPs and URLs
    <https://zeltser.com/malicious-ip-blocklists/>
  *
    Google Transparency Report
    <https://transparencyreport.google.com/https/certificates?hl=en>
  *
    I-BlockList
    <https://www.iblocklist.com/lists.php>
  *
    Internet Archive: Wayback Machine
    <https://archive.org/web/web.php>
  *
    Internet-Wide Scan Data Repository
    <https://scans.io/>
  *
    IP Void
    <http://www.ipvoid.com/>
  *
    IPdeny
    <http://www.ipdeny.com/>
  *
    IPInfo
    <https://ipinfo.io/>
  *
    Majestic Million
    <https://majestic.com/reports/majestic-million>
  *
    McAfee - Check Single URL
    <https://trustedsource.org/sources/index.pl>
  *
    MX Toolbox - ASN Lookup
    <https://mxtoolbox.com/asn.aspx>
  *
    MX Toolbox - Email Server Blacklist Check
    <https://mxtoolbox.com/blacklists.aspx>
  *
    Netbootcamp - Website Investigation Tool
    <http://netbootcamp.org/websitetool.html>
  *
    Neustar IP & Geolocation Lookup Tool
    <https://www.risk.neustar/resources/tools/ip-geolocation-lookup-tool>
  *
    Neustar UltraTools - ASN Lookup Tool
    <https://www.ultratools.com/tools>
  *
    Online Curl
    <https://onlinecurl.com/>
  *
    Quttera Online Website Malware Scanner
    <https://quttera.com/website-malware-scanner>
  *
    Quttera WordPress Malware Scanner plugin
    <https://quttera.com/wordpress-malware-scanner>
  *
    RIPE registration info
    <https://apps.db.ripe.net/db-web-ui/#/query>
  *
    Rutgers IP List of SSH/RDP Brute Force Attackers
    <http://report.cs.rutgers.edu/mrtg/drop/dropstat.cgi?start=-86400>
  *
    SANS ISC: Suspicious Domains SANS Site Network Current Site Internet
    Storm Center Other SANS Sites Help Graduate Degree Programs Security
    Training Security Certification Security Awareness Training
    Penetration Testing Industrial Control Systems Cyber Defense
    Foundations DFIR Software Security Government OnSite Training
    Suspicious Domains
    <https://isc.sans.edu/suspicious_domains.html>
  *
    SecurityTrails - SurfaceBrowser (PAID)
    <https://securitytrails.com/corp/surfacebrowser>
  *
    SecurityTrails (PAID)
    <https://securitytrails.com/>
  *
    SEO Keyword Graph Visualization
    <http://touchgraph.com/seo>
  *
    ServerSniff
    <https://www.serversniff.net/>
  *
    Statvoo
    <https://statvoo.com/>
  *
    Strongarm Malware Protection
    <https://strongarm.io/>
  *
    Symantec WebPulse Site Review Request
    <https://sitereview.bluecoat.com/#/>
  *
    Talos
    <https://talosintelligence.com/reputation>
  *
    Team Cymru IP to ASN Lookup v1.0
    <https://asn.cymru.com/>
  *
    ThreatSTOP | Operationalized Threat Intelligence
    <http://threatstop.com/>
  *
    TOR Node List
    <https://www.dan.me.uk/tornodes>
  *
    URL Void
    <http://www.urlvoid.com/>
  *
    URL X-ray
    <http://urlxray.com/>
  *
    URLhaus | Malware URL exchange
    <https://urlhaus.abuse.ch/>
  *
    urlQuery
    <https://urlquery.net/>
  *
    ViewDNS.info
    <http://viewdns.info/>
  *
    VX Vault
    <http://vxvault.net/ViriList.php>
  *
    Web Filter Lookup
    <https://fortiguard.com/webfilter>
  *
    What My IP Address?
    <http://whatmyip.co/>
  *
    WhatIsMyIP.com
    <https://www.whatismyip.com/>
  *
    yougetsignal - Network Tools
    <https://www.yougetsignal.com/>
  *
    Zone-H.org
    <https://zone-h.org/> 




   # Domain / IP Research - WhoIs

  *
    .edu Whois Lookup
    <https://net.educause.edu/whois.htm>
  *
    The Prefix WhoIs Project
    <http://pwhois.org/>
  *
    ARIN Whois-RWS
    <http://whois.arin.net/ui/advanced.jsp>
  *
    da whois
    <https://dawhois.com/>
  *
    DomainTools - Reverse Whois
    <http://reversewhois.domaintools.com/>
  *
    DomainTools Whois Lookup
    <https://whois.domaintools.com/>
  *
    IANA WhoIs Service
    <https://www.iana.org/whois>
  *
    InterNIC | Whois
    <http://internic.net/whois.html>
  *
    NSI - WhoIs
    <http://networksolutions.com/whois/index.jsp>
  *
    Whois.com
    <https://www.whois.com/whois/>
  *
    Whois.net
    <https://whois.net/>
  *
    Whoisology
    <https://whoisology.com/> 




   # Geolocation

  *
    BatchGeo: Create an interactive map from your data
    <https://batchgeo.com/>
  *
    Creepy by ilektrojohn
    <http://www.geocreepy.com/>
  *
    Echosec (PAID)
    <https://www.echosec.net/>
  *
    FireHOL IP Lists
    <https://iplists.firehol.org/>
  *
    IP2Location
    <https://www.ip2location.com/>
  *
    IPdeny IP country blocks
    <http://www.ipdeny.com/>
  *
    IPGeek
    <http://www.ipgeeks.org/>
  *
    IPIP.NET
    <https://en.ipip.net/ip.html>
  *
    Maxmind
    <https://www.maxmind.com/en/open-source-data-and-api-for-ip-geolocation>

  *
    WiGLE: Wireless Network Mapping
    <https://wigle.net/> 




   # Research

  *
    8ackprotect
    <https://8ackprotect.com/>
  *
    AlienVault OTX
    <https://www.alienvault.com/open-threat-exchange>
  *
    Blueliv Threat Exchange Network
    <http://community.blueliv.com/>
  *
    Certstream
    <https://certstream.calidog.io/>
  *
    Cyber Analytics Repository Exploration Tool
    <https://car.mitre.org/caret/#/>
  *
    ET Rules
    <https://rules.emergingthreats.net/>
  *
    FluidDATA - Podcast Search Engine
    <https://fluiddata.com/>
  *
    G Suite toolbox
    <https://toolbox.googleapps.com/apps/main/>
  *
    Global FTP Search Engine
    <http://globalfilesearch.com/>
  *
    Google Hacking Database (GHDB)
    <http://exploit-db.com/google-hacking-database>
  *
    GreyNoise Visualizer
    <https://viz.greynoise.io/table>
  *
    hpHosts
    <https://hosts-file.net/>
  *
    Hunter
    <https://hunter.io/>
  *
    Hurricane Electric Network Looking Glass
    <https://lg.he.net/>
  *
    IBM X-Force Exchange
    <https://exchange.xforce.ibmcloud.com/>
  *
    INFOSEC - CERT-PA
    <https://infosec.cert-pa.it/>
  *
    IOC Bucket
    <https://www.iocbucket.com/>
  *
    iseek.ai
    <https://iseek.com/#/web>
  *
    Malc0de Database
    <http://malc0de.com/database/>
  *
    Maltego CE
    <https://www.paterva.com/web7/buy/maltego-clients/maltego-ce.php>
  *
    MITRE - CAPEC
    <https://capec.mitre.org/>
  *
    MXToolbox
    <https://mxtoolbox.com/EmailHeaders.aspx>
  *
    NerdyData
    <https://nerdydata.com/>
  *
    NormShield Services
    <https://services.normshield.com/>
  *
    Pastebin
    <https://pastebin.com/>
  *
    PhishTank
    <https://www.phishtank.com/>
  *
    PulseDive
    <https://pulsedive.com/>
  *
    RiskIQ Community Edition
    <https://www.riskiq.com/products/community-edition/>
  *
    RiskIQ PassiveTotal Threat Investigation Platform | RiskIQ
    <https://www.riskiq.com/products/passivetotal/>
  *
    SANS ICS - InfoSec Reports
    <https://isc.sans.edu/reports.html>
  *
    SANS ICS - InfoSec Tools
    <https://isc.sans.edu/tools/>
  *
    searchcode
    <https://searchcode.com/>
  *
    Source Code Search Engine
    <https://publicwww.com/>
  *
    SparkIOC
    <https://sparkioc.com/>
  *
    SpiderFoot
    <http://spiderfoot.net/>
  *
    TC Open
    <https://www.threatconnect.com/free/>
  *
    Team Cymru - Community Services
    <http://www.team-cymru.com/community-services.html>
  *
    Threat Crowd
    <https://threatcrowd.org/>
  *
    Threat Miner
    <https://threatminer.org/>
  *
    WSTNPHX/scripts-n-tools
    <https://github.com/WSTNPHX/scripts-n-tools/blob/master/malware-email-addresses.txt>







   # Browser Add-ons

  *
    Google Translate – Add-ons for Firefox
    <https://addons.mozilla.org/en-US/firefox/addon/google-translate-for-firefox/?src=search>

  *
    IP, DNS & Security Tools | HackerTarget.com
    <https://chrome.google.com/webstore/detail/ip-dns-security-tools-hac/phjkepckmcnjohilmbjlcoblenhgpjmo?hl=en-US>

  *
    Open Source Intelligence Browser Extension
    <http://www.osintbrowser.com/>
  *
    PassiveRecon – Get this Extension for 🦊 Firefox (en-US)
    <http://addons.mozilla.org/en-US/firefox/addon/passiverecon>
  *
    Plain Text Offenders – Get this Extension for 🦊 Firefox (en-US)
    <http://addons.mozilla.org/en-US/firefox/addon/plain-text-offenders/>
  *
    Plain Text Offenders Alert - Chrome Add-on
    <http://chrome.google.com/webstore/detail/plain-text-offenders-aler/ggndaknbenjhnkddgjnjjcmomgaidhmd>

  *
    Print Friendly & PDF - Add-on for Chrome
    <https://chrome.google.com/webstore/detail/print-friendly-pdf/ohlencieiipommannpdfcmfdpjjmeolj?hl=en>

  *
    Shodan.io - Chrome Add-on
    <https://chrome.google.com/webstore/detail/shodan/jjalcfnidlmpjhdfepjhjbhnhkbgleap>

  *
    Shodan.io – Add-ons for Firefox
    <https://addons.mozilla.org/en-US/firefox/addon/shodan_io/>
  *
    start.me
    <https://addons.mozilla.org/en-US/firefox/addon/startme/?src=search>
  *
    ThreatPinch Lookup
    <https://chrome.google.com/webstore/detail/threatpinch-lookup/ljdgplocfnmnofbhpkjclbefmjoikgke?hl=eni>

  *
    TwitterGadget
    <https://chrome.google.com/webstore/detail/twittergadget-chrome-exte/nabmmeeodpeneohkhpjpmaiidagmicbo>

  *
    Zotero Connector
    <https://chrome.google.com/webstore/detail/zotero-connector/ekhagklcjbdpajgpjgmbionohlpdbjgc>





   # Live Distros

  *
    Buscador OSINT VM
    <https://inteltechniques.com/buscador/>
  *
    Tsurugi Linux
    <https://tsurugi-linux.org/>
  *
    OSINT with Buscador
    <https://holisticinfosec.blogspot.com/2018/01/toolsmith-130-osint-with-buscador.html>





   # Software

  *
    aboul3la/Sublist3r
    <https://github.com/aboul3la/Sublist3r>
  *
    activecm/rita
    <https://github.com/activecm/rita>
  *
    AlienVault-OTX/ApiV2
    <https://github.com/AlienVault-OTX/ApiV2>
  *
    althonos/InstaLooter
    <https://github.com/althonos/InstaLooter>
  *
    armbues/ioc_parser
    <https://github.com/armbues/ioc_parser>
  *
    AstroGrep
    <http://astrogrep.sourceforge.net/>
  *
    Awesome OSINT
    <https://github.com/jivoi/awesome-osint>
  *
    Awesome Threat Intelligence
    <https://github.com/hslatman/awesome-threat-intelligence>
  *
    Awesome VirusTotal Intelligence Search Queries
    <https://github.com/Neo23x0/vti-dorks>
  *
    Cheap Bots,  Quick!
    <https://cheapbotsquick.com/>
  *
    Collective Intelligence Framework (CIF)
    <https://csirtgadgets.com/collective-intelligence-framework>
  *
    dfirgeek/cabby
    <https://github.com/eclecticiq/cabby>
  *
    douagiep16/actortrackr
    <http://github.com/douagiep16/actortrackr>
  *
    Eleven Paths - Tools
    <https://www.elevenpaths.com/labs/tools/index.html#*>
  *
    eset/malware-ioc
    <http://github.com/eset/malware-ioc>
  *
    exp0se/bro-intel-generator
    <https://github.com/exp0se/bro-intel-generator>
  *
    exp0se/harbinger
    <https://github.com/exp0se/harbinger>
  *
    FireEye - Free Security Software
    <https://www.fireeye.com/services/freeware.html>
  *
    fireeye/iocs
    <http://github.com/fireeye/iocs>
  *
    firehol/blocklist-ipsets
    <http://github.com/firehol/blocklist-ipsets>
  *
    FOCA
    <https://www.elevenpaths.com/labstools/foca/index.html>
  *
    github.com/lockfale/osint-framework
    <https://github.com/lockfale/osint-framework>
  *
    github.com/twintproject/twint
    <https://github.com/twintproject/twint>
  *
    github.com/tylabs/quicksand_lite
    <https://github.com/tylabs/quicksand_lite>
  *
    GitMiner
    <https://github.com/UnkL4b/GitMiner>
  *
    Gitrob
    <https://github.com/michenriksen/gitrob>
  *
    GreyNoise-Intelligence API
    <https://github.com/GreyNoise-Intelligence/api.greynoise.io>
  *
    HA71/Namechk
    <http://github.com/HA71/Namechk>
  *
    HurricaneLabs/machinae
    <http://github.com/HurricaneLabs/machinae>
  *
    iDefense/ig-query
    <https://github.com/iDefense/ig-query>
  *
    Introducing OSINT YOGA
    <https://webbreacher.com/2018/06/24/introducing-osint-yoga/>
  *
    jheise/threatcmd
    <http://github.com/jheise/threatcmd>
  *
    jheise/threatcrowd_api
    <https://github.com/jheise/threatcrowd_api>
  *
    johestephan/ibmxforceex.checker.py
    <https://github.com/johestephan/ibmxforceex.checker.py>
  *
    jpsenior/threataggregator
    <https://github.com/jpsenior/threataggregator>
  *
    kevthehermit/RATDecoders
    <http://github.com/kevthehermit/RATDecoders>
  *
    kx499/ostip/wiki
    <http://github.com/kx499/ostip/wiki>
  *
    laramies/metagoofil
    <https://github.com/laramies/metagoofil>
  *
    laramies/theHarvester
    <http://github.com/laramies/theHarvester>
  *
    lnxg33k/MHA
    <https://github.com/lnxg33k/MHA>
  *
    maldevel/EmailHarvester
    <http://github.com/maldevel/EmailHarvester>
  *
    mandiant/ioc_writer
    <http://github.com/mandiant/ioc_writer>
  *
    martenson/disposable-email-domains
    <https://github.com/martenson/disposable-email-domains>
  *
    mgeide/poortego
    <https://github.com/mgeide/poortego>
  *
    michael-yip/ThreatTracker
    <https://github.com/michael-yip/ThreatTracker>
  *
    michenriksen/aquatone
    <https://github.com/michenriksen/aquatone>
  *
    MISP/MISP
    <https://github.com/MISP/MISP>
  *
    MISP/MISP-Taxii-Server
    <https://github.com/MISP/MISP-Taxii-Server>
  *
    MISP/misp-workbench
    <https://github.com/MISP/misp-workbench>
  *
    mlsecproject/combine
    <https://github.com/mlsecproject/combine>
  *
    mlsecproject/tiq-test
    <https://github.com/mlsecproject/tiq-test>
  *
    mrbrutti/esearchy-ng
    <https://github.com/mrbrutti/esearchy-ng>
  *
    needmorecowbell/giggity
    <https://github.com/needmorecowbell/giggity>
  *
    Neo23x0/Fenrir
    <https://github.com/Neo23x0/Fenrir>
  *
    Neo23x0/signature-base
    <https://github.com/Neo23x0/signature-base>
  *
    PayloadSecurity/VxAPI
    <https://github.com/PayloadSecurity/VxAPI>
  *
    Project Jupyter (Jupyter Notebook)
    <https://jupyter.org/>
  *
    Scythe
    <http://github.com/ChrisJohnRiley/Scythe>
  *
    smicallef/spiderfoot
    <https://github.com/smicallef/spiderfoot>
  *
    SupportIntelligence/Icewater
    <https://github.com/SupportIntelligence/Icewater>
  *
    URLScan.io
    <https://urlscan.io/>
  *
    WebBreacher/yoga
    <https://github.com/WebBreacher/yoga>
  *
    woj-ciech/Daily-dose-of-malware
    <https://github.com/woj-ciech/Daily-dose-of-malware>
  *
    WSTNPHX/scripts-n-tools
    <https://github.com/WSTNPHX/scripts-n-tools>
  *
    xillwillx/skiptracer
    <https://github.com/xillwillx/skiptracer>
  *
    xmendez/wfuzz
    <https://github.com/xmendez/wfuzz> 




   # Stealth

  *
    I2P Anonymous Network
    <https://geti2p.net/en/>
  *
    Privoxy
    <https://www.privoxy.org/>
  *
    Tor Project
    <https://www.torproject.org/>
  *
    Windscribe
    <https://windscribe.com/> 




   # Tools - Visualization

  *
    Gephi
    <https://gephi.org/>
  *
    Kineviz GraphXR
    <https://www.kineviz.com/> 




   # Tools - File/Website Copiers

  *
    HTTrack Website Copier
    <https://www.httrack.com/>
  *
    Wget - GNU Project
    <https://www.gnu.org/software/wget/> 




   # Tools - Productivity

  *
    Atom text editor
    <https://atom.io/>
  *
    Gedit
    <https://wiki.gnome.org/Apps/Gedit>
  *
    /

    /
    Hex Editor
    <https://www.sweetscape.com/010e%20ditor/>
  *
    Kate | Get an Edge in Editing – The Kate Editor Homepage
    <https://kate-editor.org/>
  *
    Kleopatra - OpenPGP
    <https://www.openpgp.org/software/kleopatra/>
  *
    wxHexEditor
    <https://www.wxhexeditor.org/> 






   # Malware - Blogs / Resources

  *
    BAE Systems Threat Research Blog
    <http://baesystemsai.blogspot.de/>
  *
    Biebs the Malware Guy's Blog
    <https://biebermalware.wordpress.com/>
  *
    Blaze's Security Blog
    <https://bartblaze.blogspot.com/>
  *
    Cisco's Talos Intelligence Group Blog
    <http://blog.talosintel.com/>
  *
    malware@prevenity blog
    <http://malware.prevenity.com/>
  *
    Malwarebytes Forums
    <https://forums.malwarebytes.com/>
  *
    Malwarebytes Labs Blog
    <http://blog.malwarebytes.com/>
  *
    MalwareMustDie! Blog
    <http://blog.malwaremustdie.org/>
  *
    S!Ri.URZ
    <https://siri-urz.blogspot.com/> 




   # Malware - File Analysis

  *
    Any Run
    <https://app.any.run/>
  *
    Hybrid Analysis
    <https://www.hybrid-analysis.com/>
  *
    Intezer Analyze
    <https://analyze.intezer.com/>
  *
    IRIS-H Digital Forensics
    <https://iris-h.services/#/pages/dashboard>
  *
    Joe Sandbox
    <https://www.joesandbox.com/>
  *
    Jotti's malware scan
    <https://virusscan.jotti.org/en>
  *
    Malicious PDF Analysis
    <https://zeltser.com/tools-for-malicious-pdf-analysis/>
  *
    malwaretracker.com
    <https://malwaretracker.com/>
  *
    OPSWAT MetaDefender File Analysis
    <https://metadefender.opswat.com/#!/>
  *
    PacketTotal
    <https://packettotal.com/>
  *
    PDF Analysis Tools
    <https://blog.didierstevens.com/programs/pdf-tools/>
  *
    PDF Explorer
    <https://www.rttsoftware.com/pdfe.html>
  *
    PDF Stream Dumper
    <http://sandsprite.com/blogs/index.php?uid=7&pid=57>
  *
    PDFExaminer: pdf malware analysis
    <https://www.pdfexaminer.com/>
  *
    PEframe
    <https://github.com/guelfoweb/peframe>
  *
    PPEE
    <https://www.mzrst.com/>
  *
    Quicksand.io Document Analyzer
    <https://www.quicksand.io/>
  *
    radare
    <https://www.radare.org/r/>
  *
    radareorg/cutter
    <https://github.com/radareorg/cutter>
  *
    Totalhash - Malware File Analysis
    <https://totalhash.cymru.com/upload/>
  *
    VirSCAN.org
    <http://www.virscan.org/>
  *
    VirusShare-related archives
    <https://a4lg.com/downloads/vxshare/>
  *
    VirusShare.com
    <https://virusshare.com/>
  *
    VirusTotal - File Analysis
    <https://www.virustotal.com/> 




   # Malware - Info

  *
    Fidelis Cybersecurity Threat Advisories
    <http://fidelissecurity.com/threat-advisories>
  *
    Malware Forensic Field Guides
    <http://www.malwarefieldguide.com/>
  *
    MalwareTips
    <https://malwaretips.com/> 




   # Malware - Ransomware

  *
    Free Ransomware Decryptors - Kaspersky Lab
    <https://noransom.kaspersky.com/>
  *
    Ransomware Tracker
    <https://ransomwaretracker.abuse.ch/>
  *
    The No More Ransom Project
    <https://www.nomoreransom.org/en/index.html>
  *
    Ransomware Catalog
    <https://docs.google.com/spreadsheets/d/1TWS238xacAto-fLKh1n5uTsdijWdCEsGIM0Y0Hvmc5g/pubhtml>





   # Malware - Research

  *
    #totalhash - Malware Analysis Database
    <https://totalhash.cymru.com/>
  *
    abuse.ch | Fighting malware and botnets
    <https://abuse.ch/>
  *
    AVCaesar (by Malware.lu)
    <https://avcaesar.malware.lu/>
  *
    Barracuda Labs Threatglass
    <http://threatglass.com/>
  *
    BotScout.com
    <https://botscout.com/search.htm>
  *
    CIRCL
    <https://circl.lu/>
  *
    Cymon
    <https://www.cymon.io/>
  *
    Digital Certificates Used by Malware
    <http://www.ccssforum.org/malware-certificates.php>
  *
    DNS-BH
    <http://www.malwaredomains.com/?page_id=66>
  *
    Exploitalert
    <https://exploitalert.com/>
  *
    Feodo Tracker
    <http://feodotracker.abuse.ch/>
  *
    Fortinet Threat Encyclopedia
    <https://fortiguard.com/encyclopedia>
  *
    JSUnpack
    <http://jsunpack.jeek.org/>
  *
    Kaspersky Labs
    <https://threats.kaspersky.com/>
  *
    malc0de DNS Sinkhole
    <http://malc0de.com/bl/>
  *
    Malekal's Forum
    <http://malwaredb.malekal.com/>
  *
    MalShare
    <https://malshare.com/>
  *
    Maltiverse
    <https://www.maltiverse.com/>
  *
    Malware Domain List
    <https://www.malwaredomainlist.com/>
  *
    Malware Patrol
    <https://www.malwarepatrol.net/>
  *
    Malware.md
    <https://gist.github.com/rjmolesa/34c6a299c17a486ea80f>
  *
    MalwareConfig
    <http://malwareconfig.com/>
  *
    Malwr
    <https://malwr.com/>
  *
    Munin
    <https://github.com/Neo23x0/munin>
  *
    NoThink!
    <http://www.nothink.org/honeypots.php>
  *
    Offensive Security’s Exploit Database Archive
    <https://www.exploit-db.com/>
  *
    Open Threat Intelligence
    <https://cymon.io/>
  *
    OWASP File Hash Repository
    <https://www.owasp.org/index.php/OWASP_File_Hash_Repository>
  *
    Sucuri Security - malware entries
    <http://labs.sucuri.net/?malware>
  *
    Sucuri Security - malware signatures
    <http://labs.sucuri.net/?malwaredb>
  *
    Team Cymru SHA1/MD5 MHR Lookup
    <http://hash.cymru.com/>
  *
    Threat Descriptions
    <https://www.f-secure.com/en/web/labs_global/threat-descriptions>
  *
    Threat Grid
    <http://www.threatgrid.com/>
  *
    VirusTotal - Search
    <https://www.virustotal.com/#/home/search>
  *
    WSTNPHX Malware Email Addresses
    <https://raw.githubusercontent.com/WSTNPHX/scripts-n-tools/master/malware-email-addresses.txt>

  *
    ZeuS Tracker
    <https://zeustracker.abuse.ch/> 




   # Malware - Research Software

  *
    github.com/urule99/jsunpack-n
    <https://github.com/urule99/jsunpack-n>
  *
    Malzilla
    <http://malzilla.sourceforge.net/>
  *
    YARA - The pattern matching swiss knife for malware researchers
    <http://virustotal.github.io/yara/>
  *
    Yara-Rules/rules
    <https://github.com/Yara-Rules/rules> 




   # Malware - Samples

  *
    contagio malware dump
    <https://contagiodump.blogspot.com/>
  *
    DAS MALWERK
    <http://dasmalwerk.eu/>
  *
    Malware.one
    <https://malware.one/> 




   # Malware - Tools

  *
    fireeye/flare-floss
    <https://github.com/fireeye/flare-floss>
  *
    Neo23x0/stringex.sh
    <https://gist.github.com/Neo23x0/cd4934a06a616ecf6cf44e36f323e551> 




   # Red Team - Misc

  *
    CIRT.net - Default Passwords
    <https://cirt.net/passwords>
  *
    CVE security vulnerability database
    <https://www.cvedetails.com/>
  *
    Exploit Database
    <https://www.exploit-db.com/about-exploit-db/>
  *
    KatzKatz:
    <https://github.com/xFreed0m/KatzKatz>
  *
    masscan
    <https://github.com/robertdavidgraham/masscan>
  *
    ODIN
    <https://github.com/chrismaddalena/ODIN>
  *
    recon-ng
    <https://bitbucket.org/LaNMaSteR53/recon-ng/src/master/>
  *
    The Hackers Arsenal Tools Portal
    <https://www.toolswatch.org/>